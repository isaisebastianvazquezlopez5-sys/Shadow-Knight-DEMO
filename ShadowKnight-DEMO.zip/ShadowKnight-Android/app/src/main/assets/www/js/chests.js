
class ChestSystem {
  constructor(scene) {
    this.scene = scene;
    this.coins = 0;
    this.opened = new Set();
    this.chests = [];
  }

  create(x, y) {
    const chest = this.scene.add.container(x, y);

    const glow = this.scene.add.circle(0, 0, 45, 0xffd66b, 0).setScale(0.4);

    const base = this.scene.add.rectangle(
      0, 8, 62, 42, 0x684225
    ).setStrokeStyle(3, 0xe0a34e);

    const lid = this.scene.add.rectangle(
      0, -15, 66, 20, 0xa66b32
    ).setStrokeStyle(3, 0xf2c36c);

    const lock = this.scene.add.rectangle(
      0, 5, 10, 15, 0xffd66b
    );

    chest.add([glow, base, lid, lock]);
    chest.setSize(75, 65);
    chest.setDepth(15);

    // cartelito que invita a tocar el cofre
    const hint = this.scene.add.text(x, y - 58, "¡TOCA!", {
      fontSize: "18px",
      color: "#ffd66b",
      fontStyle: "bold",
      stroke: "#000000",
      strokeThickness: 4
    }).setOrigin(0.5).setDepth(16);

    const hintTween = this.scene.tweens.add({
      targets: hint,
      y: hint.y - 8,
      yoyo: true,
      repeat: -1,
      duration: 600,
      ease: "Sine.easeInOut"
    });

    const item = {
      container: chest,
      lid,
      lock,
      glow,
      hint,
      hintTween,
      opened: false,
      x,
      y
    };

    // zona táctil grande para abrir con un solo toque
    chest.setInteractive(
      new Phaser.Geom.Rectangle(-60, -60, 120, 115),
      Phaser.Geom.Rectangle.Contains
    );

    chest.on("pointerdown", () => {
      if (this.scene.uiLocked) return;
      if (typeof inventory !== "undefined" && inventory.visible) return;
      if (typeof shop !== "undefined" && shop.panel) return;
      this.open(item);
    });

    this.chests.push(item);
    return item;
  }

  update(delta) {
    // ya no hay que mantener presionado: se abre con un toque
  }

  open(chest) {
    if (chest.opened) return;
    chest.opened = true;

    const scene = this.scene;
    const x = chest.x;
    const y = chest.y;

    GameAudio.chest();

    if (chest.hintTween) chest.hintTween.stop();
    if (chest.hint) chest.hint.destroy();
    chest.lock.destroy();

    // tapa que se abre
    scene.tweens.add({
      targets: chest.lid,
      angle: -35,
      y: -28,
      x: -6,
      duration: 300,
      ease: "Back.Out"
    });

    // brillo dorado
    chest.glow.setFillStyle(0xffd66b, 0.55);
    scene.tweens.add({
      targets: chest.glow,
      scale: 2.2,
      alpha: 0,
      duration: 600,
      ease: "Quad.Out"
    });

    // cofre da un saltito
    scene.tweens.add({
      targets: chest.container,
      scaleY: 1.12,
      scaleX: 0.94,
      yoyo: true,
      duration: 110
    });

    // rayos de luz
    for (let i = 0; i < 7; i++) {
      const ray = scene.add.rectangle(x, y - 10, 4, 38, 0xfff2a8, 0.9)
        .setDepth(14)
        .setAngle(-90 + i * 30);
      const dist = 70 + Math.random() * 25;
      const a = Phaser.Math.DegToRad(-90 + i * 30 - 90 + 90);
      scene.tweens.add({
        targets: ray,
        x: x + Math.cos(Phaser.Math.DegToRad(-180 + i * 30)) * dist,
        y: y - 10 + Math.sin(Phaser.Math.DegToRad(-180 + i * 30)) * dist,
        alpha: 0,
        scaleY: 0.2,
        duration: 550,
        onComplete: () => ray.destroy()
      });
    }

    // monedas que saltan
    for (let i = 0; i < 12; i++) {
      const coin = scene.add.circle(x, y - 12, 6, 0xffd66b)
        .setStrokeStyle(2, 0xb8860b)
        .setDepth(30);
      const dx = (Math.random() - 0.5) * 170;
      scene.tweens.add({
        targets: coin,
        x: x + dx,
        duration: 700,
        ease: "Linear"
      });
      scene.tweens.add({
        targets: coin,
        y: y - 70 - Math.random() * 70,
        duration: 330,
        ease: "Quad.Out",
        yoyo: true,
        onYoyo: () => {
          scene.tweens.add({
            targets: coin,
            alpha: 0,
            delay: 250,
            duration: 150,
            onComplete: () => coin.destroy()
          });
        }
      });
    }

    this.coins += 25;

    const reward = scene.add.text(
      x, y - 65, "+25 MONEDAS",
      {
        fontSize: "24px",
        color: "#ffd66b",
        fontStyle: "bold",
        stroke: "#000000",
        strokeThickness: 5
      }
    ).setOrigin(0.5).setDepth(100).setScale(0.4);

    scene.tweens.add({
      targets: reward,
      scale: 1,
      duration: 250,
      ease: "Back.Out"
    });

    scene.tweens.add({
      targets: reward,
      y: reward.y - 60,
      alpha: 0,
      delay: 250,
      duration: 1300,
      onComplete: () => reward.destroy()
    });
  }
}
