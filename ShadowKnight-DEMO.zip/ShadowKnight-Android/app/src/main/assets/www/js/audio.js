// Sonidos sintetizados con WebAudio (sin archivos externos)
const GameAudio = {
  ctx: null,
  master: null,
  started: false,
  dripTimer: null,

  init() {
    const unlock = () => this.start();
    ["pointerdown", "touchstart", "keydown", "click"].forEach(ev =>
      window.addEventListener(ev, unlock, { passive: true })
    );
    document.addEventListener("visibilitychange", () => {
      if (!this.ctx) return;
      if (document.hidden) this.ctx.suspend();
      else if (this.started) this.ctx.resume();
    });
  },

  muted: false,
  setMuted(m) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.9;
  },

  start() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.9;
      this.master.connect(this.ctx.destination);

      // pequeño eco/reverb para dar ambiente de cueva
      this.delay = this.ctx.createDelay(1.0);
      this.delay.delayTime.value = 0.32;
      const fb = this.ctx.createGain();
      fb.gain.value = 0.38;
      const lp = this.ctx.createBiquadFilter();
      lp.type = "lowpass";
      lp.frequency.value = 2200;
      this.delay.connect(lp);
      lp.connect(fb);
      fb.connect(this.delay);
      const wet = this.ctx.createGain();
      wet.gain.value = 0.5;
      lp.connect(wet);
      wet.connect(this.master);
    }
    if (this.ctx.state === "suspended") this.ctx.resume();
    if (this.started) return;
    this.started = true;
    this.loadDrop();
    this.startAmbient();
    this.scheduleDrip();
  },

  // --- Sonido de fondo: drone grave + viento + notas lejanas ---
  startAmbient() {
    const c = this.ctx;
    const out = c.createGain();
    out.gain.value = 0.0;
    out.gain.linearRampToValueAtTime(0.5, c.currentTime + 4);
    out.connect(this.master);

    // drone
    [55, 82.5, 110.4].forEach((f, i) => {
      const o = c.createOscillator();
      o.type = i === 0 ? "sawtooth" : "sine";
      o.frequency.value = f;
      const g = c.createGain();
      g.gain.value = i === 0 ? 0.05 : 0.07;
      const filt = c.createBiquadFilter();
      filt.type = "lowpass";
      filt.frequency.value = 260;
      const lfo = c.createOscillator();
      lfo.frequency.value = 0.07 + i * 0.03;
      const lfoG = c.createGain();
      lfoG.gain.value = 0.03;
      lfo.connect(lfoG);
      lfoG.connect(g.gain);
      o.connect(filt);
      filt.connect(g);
      g.connect(out);
      o.start();
      lfo.start();
    });

    // viento (ruido filtrado)
    const len = c.sampleRate * 2;
    const buf = c.createBuffer(1, len, c.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    const noise = c.createBufferSource();
    noise.buffer = buf;
    noise.loop = true;
    const bp = c.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 420;
    bp.Q.value = 0.8;
    const wg = c.createGain();
    wg.gain.value = 0.06;
    const wl = c.createOscillator();
    wl.frequency.value = 0.11;
    const wlg = c.createGain();
    wlg.gain.value = 0.045;
    wl.connect(wlg);
    wlg.connect(wg.gain);
    const bl = c.createOscillator();
    bl.frequency.value = 0.05;
    const blg = c.createGain();
    blg.gain.value = 180;
    bl.connect(blg);
    blg.connect(bp.frequency);
    noise.connect(bp);
    bp.connect(wg);
    wg.connect(out);
    noise.start();
    wl.start();
    bl.start();

    // notas místicas lejanas, muy suaves
    const scale = [220, 261.63, 293.66, 329.63, 392, 440];
    const note = () => {
      if (!this.ctx) return;
      const t = c.currentTime;
      const o = c.createOscillator();
      o.type = "sine";
      o.frequency.value = scale[Math.floor(Math.random() * scale.length)] / 2;
      const g = c.createGain();
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(0.05, t + 2);
      g.gain.exponentialRampToValueAtTime(0.0005, t + 7);
      o.connect(g);
      g.connect(out);
      g.connect(this.delay);
      o.start(t);
      o.stop(t + 7.2);
      setTimeout(note, 5000 + Math.random() * 7000);
    };
    setTimeout(note, 2500);
  },

  // --- Sonido de gota (tu mp3: audio/gota.mp3) ---
  loadDrop() {
    fetch("audio/gota.mp3")
      .then(r => r.arrayBuffer())
      .then(buf => this.ctx.decodeAudioData(buf))
      .then(decoded => { this.dropBuf = decoded; })
      .catch(() => {
        // plan B: reproducirlo con un elemento de audio normal
        try { this.dropAudio = new Audio("audio/gota.mp3"); } catch (e) {}
      });
  },

  drip(volume = 1, pitch = 1) {
    if (!this.ctx || this.ctx.state !== "running") return;

    if (this.dropBuf) {
      const c = this.ctx;
      const src = c.createBufferSource();
      src.buffer = this.dropBuf;
      src.playbackRate.value = pitch;
      const g = c.createGain();
      g.gain.value = Math.min(1, 0.9 * volume);
      src.connect(g);
      g.connect(this.master);
      src.start();
    } else if (this.dropAudio) {
      if (this.muted) return;
      const a = this.dropAudio.cloneNode();
      a.volume = Math.min(1, 0.9 * volume);
      a.play().catch(() => {});
    } else {
      this.dripSynth(volume, pitch);
    }
  },

  // (sonido de gota sintetizado, solo por si falla el mp3)
  dripSynth(volume = 1, pitch = 1) {
    if (!this.ctx || this.ctx.state !== "running") return;
    const c = this.ctx;
    const t = c.currentTime;
    const f0 = (1100 + Math.random() * 900) * pitch;
    const o = c.createOscillator();
    o.type = "sine";
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(f0 * 0.45, t + 0.12);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.28 * volume, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);
    o.connect(g);
    g.connect(this.master);
    g.connect(this.delay);
    o.start(t);
    o.stop(t + 0.25);
    // segundo "plop" más agudo, como rebote del agua
    const o2 = c.createOscillator();
    o2.type = "sine";
    o2.frequency.setValueAtTime(f0 * 1.9, t + 0.05);
    o2.frequency.exponentialRampToValueAtTime(f0 * 0.9, t + 0.14);
    const g2 = c.createGain();
    g2.gain.setValueAtTime(0.0001, t + 0.05);
    g2.gain.exponentialRampToValueAtTime(0.08 * volume, t + 0.06);
    g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
    o2.connect(g2);
    g2.connect(this.master);
    g2.connect(this.delay);
    o2.start(t + 0.05);
    o2.stop(t + 0.2);
  },

  scheduleDrip() {
    clearTimeout(this.dripTimer);
    const next = () => {
      this.drip(1, 1);
      this.dripTimer = setTimeout(next, 3000);   // una gota cada 3 segundos
    };
    this.dripTimer = setTimeout(next, 1500);
  },

  // --- Efectos ---
  noiseBurst(dur, freq, vol) {
    const c = this.ctx;
    const t = c.currentTime;
    const len = Math.floor(c.sampleRate * dur);
    const buf = c.createBuffer(1, len, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const s = c.createBufferSource();
    s.buffer = buf;
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = freq;
    const g = c.createGain();
    g.gain.value = vol;
    s.connect(f);
    f.connect(g);
    g.connect(this.master);
    s.start(t);
  },

  jump() {
    if (!this.ctx || this.ctx.state !== "running") return;
    const c = this.ctx, t = c.currentTime;
    const o = c.createOscillator();
    o.type = "triangle";
    o.frequency.setValueAtTime(260, t);
    o.frequency.exponentialRampToValueAtTime(520, t + 0.12);
    const g = c.createGain();
    g.gain.setValueAtTime(0.1, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.15);
    o.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + 0.16);
  },

  land(strength = 1) {
    if (!this.ctx || this.ctx.state !== "running") return;
    this.noiseBurst(0.12, 500, 0.25 * strength);
    this.drip(0.7 * strength, 0.7);
  },

  attack() {
    if (!this.ctx || this.ctx.state !== "running") return;
    this.noiseBurst(0.14, 4000, 0.22);
  },

  // Golpe que recibe el jugador: impacto grave + ruido + quejido
  hit() {
    if (!this.ctx || this.ctx.state !== "running") return;
    const c = this.ctx, t = c.currentTime;

    const o = c.createOscillator();
    o.type = "sawtooth";
    o.frequency.setValueAtTime(220, t);
    o.frequency.exponentialRampToValueAtTime(50, t + 0.25);
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 900;
    const g = c.createGain();
    g.gain.setValueAtTime(0.32, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
    o.connect(f);
    f.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + 0.32);

    this.noiseBurst(0.16, 1500, 0.3);

    const o2 = c.createOscillator();
    o2.type = "triangle";
    o2.frequency.setValueAtTime(520, t);
    o2.frequency.exponentialRampToValueAtTime(300, t + 0.16);
    const g2 = c.createGain();
    g2.gain.setValueAtTime(0.13, t);
    g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
    o2.connect(g2);
    g2.connect(this.master);
    o2.start(t);
    o2.stop(t + 0.2);
  },

  // Enemigo eliminado: caída de tono + pop + campanita
  enemyDie() {
    if (!this.ctx || this.ctx.state !== "running") return;
    const c = this.ctx, t = c.currentTime;

    const o = c.createOscillator();
    o.type = "sawtooth";
    o.frequency.setValueAtTime(420, t);
    o.frequency.exponentialRampToValueAtTime(70, t + 0.3);
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 1200;
    const g = c.createGain();
    g.gain.setValueAtTime(0.18, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.32);
    o.connect(f);
    f.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + 0.34);

    this.noiseBurst(0.2, 1800, 0.22);

    [880, 1320].forEach((fr, i) => {
      const o2 = c.createOscillator();
      o2.type = "triangle";
      o2.frequency.value = fr;
      const g2 = c.createGain();
      const st = t + 0.16 + i * 0.07;
      g2.gain.setValueAtTime(0.0001, st);
      g2.gain.exponentialRampToValueAtTime(0.09, st + 0.01);
      g2.gain.exponentialRampToValueAtTime(0.0001, st + 0.22);
      o2.connect(g2);
      g2.connect(this.master);
      o2.start(st);
      o2.stop(st + 0.25);
    });
  },

  // Golpe de espada al jefe
  bossHit() {
    if (!this.ctx || this.ctx.state !== "running") return;
    this.noiseBurst(0.1, 2200, 0.2);
    const c = this.ctx, t = c.currentTime;
    const o = c.createOscillator();
    o.type = "square";
    o.frequency.setValueAtTime(140, t);
    o.frequency.exponentialRampToValueAtTime(70, t + 0.1);
    const g = c.createGain();
    g.gain.setValueAtTime(0.12, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
    o.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + 0.14);
  },

  // El jefe se prepara para embestir
  bossRoar() {
    if (!this.ctx || this.ctx.state !== "running") return;
    const c = this.ctx, t = c.currentTime;
    const o = c.createOscillator();
    o.type = "sawtooth";
    o.frequency.setValueAtTime(90, t);
    o.frequency.exponentialRampToValueAtTime(45, t + 0.55);
    const f = c.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 500;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.3, t + 0.08);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);
    o.connect(f);
    f.connect(g);
    g.connect(this.master);
    g.connect(this.delay);
    o.start(t);
    o.stop(t + 0.65);
  },

  // Jefe derrotado: explosión + fanfarria corta
  bossDie() {
    if (!this.ctx || this.ctx.state !== "running") return;
    const c = this.ctx, t = c.currentTime;
    this.noiseBurst(0.7, 1400, 0.35);
    const o = c.createOscillator();
    o.type = "sawtooth";
    o.frequency.setValueAtTime(300, t);
    o.frequency.exponentialRampToValueAtTime(40, t + 0.8);
    const g = c.createGain();
    g.gain.setValueAtTime(0.25, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
    o.connect(g);
    g.connect(this.master);
    g.connect(this.delay);
    o.start(t);
    o.stop(t + 0.95);

    [523.25, 659.25, 783.99, 1046.5].forEach((fr, i) => {
      const o2 = c.createOscillator();
      o2.type = "triangle";
      o2.frequency.value = fr;
      const g2 = c.createGain();
      const st = t + 0.5 + i * 0.13;
      g2.gain.setValueAtTime(0.0001, st);
      g2.gain.exponentialRampToValueAtTime(0.16, st + 0.02);
      g2.gain.exponentialRampToValueAtTime(0.0001, st + 0.5);
      o2.connect(g2);
      g2.connect(this.master);
      g2.connect(this.delay);
      o2.start(st);
      o2.stop(st + 0.55);
    });
  },

  // Caída al vacío: silbido descendente + gotas al final
  fall() {
    if (!this.ctx || this.ctx.state !== "running") return;
    const c = this.ctx, t = c.currentTime;
    const o = c.createOscillator();
    o.type = "sine";
    o.frequency.setValueAtTime(900, t);
    o.frequency.exponentialRampToValueAtTime(140, t + 0.9);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.16, t + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.95);
    o.connect(g);
    g.connect(this.master);
    g.connect(this.delay);
    o.start(t);
    o.stop(t + 1);
    setTimeout(() => this.drip(1, 0.6), 650);
    setTimeout(() => this.drip(0.7, 0.8), 900);
  },

  chest() {
    if (!this.ctx || this.ctx.state !== "running") return;
    const c = this.ctx, t = c.currentTime;
    // crujido de la tapa
    this.noiseBurst(0.18, 900, 0.22);
    // monedas: notas agudas rápidas
    [784, 988, 1175, 1568, 1319, 1568].forEach((f, i) => {
      const o = c.createOscillator();
      o.type = "triangle";
      o.frequency.value = f;
      const g = c.createGain();
      const st = t + 0.12 + i * 0.07;
      g.gain.setValueAtTime(0.0001, st);
      g.gain.exponentialRampToValueAtTime(0.14, st + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, st + 0.25);
      o.connect(g);
      g.connect(this.master);
      g.connect(this.delay);
      o.start(st);
      o.stop(st + 0.3);
    });
  },

  respawn() {
    if (!this.ctx || this.ctx.state !== "running") return;
    const c = this.ctx, t = c.currentTime;
    [392, 523.25, 659.25].forEach((f, i) => {
      const o = c.createOscillator();
      o.type = "sine";
      o.frequency.value = f;
      const g = c.createGain();
      g.gain.setValueAtTime(0.0001, t + i * 0.09);
      g.gain.exponentialRampToValueAtTime(0.12, t + i * 0.09 + 0.03);
      g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.09 + 0.5);
      o.connect(g);
      g.connect(this.master);
      g.connect(this.delay);
      o.start(t + i * 0.09);
      o.stop(t + i * 0.09 + 0.55);
    });
  }
};

GameAudio.init();
