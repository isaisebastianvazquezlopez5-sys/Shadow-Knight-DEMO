
class WeaponShop {
  constructor(scene, inventory) {
    this.scene = scene;
    this.inventory = inventory;

    this.weapons = [
      {
        name: "Espada de hierro",
        damage: 1,
        price: 0,
        color: 0xb8c5d9
      },
      {
        name: "Espada de fuego",
        damage: 2,
        price: 100,
        color: 0xff713d
      },
      {
        name: "Espada de hielo",
        damage: 3,
        price: 250,
        color: 0x69dfff
      },
      {
        name: "Espada de sombras",
        damage: 5,
        price: 500,
        color: 0x9c72ff
      }
    ];

    this.currentWeapon = this.weapons[0];
    this.purchased = [this.weapons[0].name];
    this.inventory.addItem(this.weapons[0].name, "weapon", 1);
    this.panel = null;
  }

  buyWeapon(name) {
    const weapon = this.weapons.find(w => w.name === name);

    if (!weapon) return false;

    if (this.purchased.includes(name)) {
      this.currentWeapon = weapon;
      if (typeof saveGame === "function") saveGame();
      return true;
    }

    if (!this.inventory.spendCoins(weapon.price)) {
      return false;
    }

    this.purchased.push(name);
    this.inventory.addItem(name, "weapon", 1);
    this.currentWeapon = weapon;
    if (typeof saveGame === "function") saveGame();

    return true;
  }

  playMoney() {
    try {
      if (typeof GameAudio !== "undefined" && GameAudio.muted) return;
      if (!this.moneyAudio) this.moneyAudio = new Audio("audio/money.mp3");
      this.moneyAudio.currentTime = 0;
      this.moneyAudio.volume = 1;
      const p = this.moneyAudio.play();
      if (p && p.catch) p.catch(() => {});
    } catch (e) {}
  }

  close() {
    if (this.panel) {
      this.panel.destroy();
      this.panel = null;
    }
  }

  open() {
    this.render();
  }

  render(message) {
    if (this.panel) {
      this.panel.destroy();
    }

    const scene = this.scene;

    this.panel = scene.add.container(GAME_W / 2, 360)
      .setScrollFactor(0)
      .setDepth(400);

    // todos los hijos fijos a la pantalla (si no, los toques fallan al mover la cámara)
    const add = o => {
      o.setScrollFactor(0);
      this.panel.add(o);
      return o;
    };

    add(scene.add.rectangle(0, 0, 650, 450, 0x111a2c, 0.98)
      .setStrokeStyle(3, 0x8c9dce));

    add(scene.add.text(-290, -195, "TIENDA DE ARMAS", {
      fontSize: "28px",
      color: "#ffffff",
      fontStyle: "bold"
    }));

    add(scene.add.text(-290, -160, "🪙 " + this.inventory.coins, {
      fontSize: "18px",
      color: "#ffd86b"
    }));

    if (message) {
      add(scene.add.text(0, 190, message, {
        fontSize: "16px",
        color: "#ffb3bf"
      }).setOrigin(0.5));
    }

    this.weapons.forEach((weapon, i) => {
      const y = -100 + i * 72;
      const owned = this.purchased.includes(weapon.name);
      const equipped = this.currentWeapon === weapon;

      add(scene.add.text(
        -275, y + 8,
        `${weapon.name}  |  ${weapon.damage} daño  |  ${weapon.price} monedas`,
        { fontSize: "17px", color: "#dce5ff" }
      ));

      const label = equipped ? "EQUIPADA" : owned ? "EQUIPAR" : "COMPRAR";

      const button = add(scene.add.text(200, y, label, {
        fontSize: "17px",
        color: equipped ? "#ffd86b" : "#75e5bd",
        backgroundColor: "#263956",
        padding: { x: 12, y: 10 }
      }));

      if (!equipped) {
        button.setInteractive({ useHandCursor: true });
        button.on("pointerdown", () => {
          if (owned) {
            this.buyWeapon(weapon.name);
            this.render();
            return;
          }

          if (this.inventory.coins < weapon.price) {
            this.render("No tienes suficientes monedas");
            return;
          }

          if (this.buyWeapon(weapon.name)) {
            this.playMoney();
            this.render();
          }
        });
      }
    });

    const close = add(scene.add.text(262, -205, "✕", {
      fontSize: "28px",
      color: "#ff8295",
      padding: { x: 14, y: 10 }
    }));

    close.setInteractive({ useHandCursor: true });
    close.on("pointerdown", () => this.close());
  }
}
