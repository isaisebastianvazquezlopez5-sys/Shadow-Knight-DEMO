
class InventorySystem {
  constructor(scene) {
    this.scene = scene;
    this.items = [];
    this.maxSlots = 12;
    this.visible = false;
    this.coins = 0;
    this.selected = -1;
    this.message = "";
  }

  addItem(name, type, quantity = 1) {
    const existing = this.items.find(item => item.name === name);

    if (existing) {
      existing.quantity += quantity;
      return true;
    }

    if (this.items.length >= this.maxSlots) {
      return false;
    }

    this.items.push({ name, type, quantity });
    return true;
  }

  removeItem(name, quantity = 1) {
    const item = this.items.find(item => item.name === name);

    if (!item || item.quantity < quantity) return false;

    item.quantity -= quantity;

    if (item.quantity <= 0) {
      this.items = this.items.filter(i => i !== item);
    }

    return true;
  }

  addCoins(amount) {
    this.coins += amount;
  }

  spendCoins(amount) {
    if (this.coins < amount) return false;

    this.coins -= amount;
    return true;
  }

  toggle() {
    this.visible = !this.visible;
    this.selected = -1;
    this.message = "";

    if (this.panel) {
      this.panel.destroy();
      this.panel = null;
    }

    if (this.visible) {
      this.draw();
    }
  }

  // datos del arma (daño, etc.) si el objeto es un arma de la tienda
  weaponOf(item) {
    if (!item || item.type !== "weapon" || typeof shop === "undefined" || !shop) return null;
    return shop.weapons.find(w => w.name === item.name) || null;
  }

  isEquipped(item) {
    const w = this.weaponOf(item);
    return !!(w && shop.currentWeapon === w);
  }

  // USAR un objeto: las armas se equipan al instante
  useItem(item) {
    const w = this.weaponOf(item);

    if (w) {
      shop.currentWeapon = w;
      this.message = "¡" + w.name + " equipada!";
      if (typeof saveGame === "function") saveGame();
    } else {
      this.message = "Este objeto no se puede usar";
    }

    this.draw();
  }

  draw() {
    const scene = this.scene;

    if (this.panel) {
      this.panel.destroy();
    }

    this.panel = scene.add.container(GAME_W / 2, 360)
      .setScrollFactor(0)
      .setDepth(300);

    // todos los hijos fijos a la pantalla (si no, los toques fallan al mover la cámara)
    const add = o => {
      o.setScrollFactor(0);
      this.panel.add(o);
      return o;
    };

    add(scene.add.rectangle(0, 0, 560, 420, 0x10182a, 0.97)
      .setStrokeStyle(3, 0x8097c7));

    add(scene.add.text(-240, -185, "MOCHILA", {
      fontSize: "30px",
      color: "#d5e2ff",
      fontStyle: "bold"
    }));

    for (let i = 0; i < this.maxSlots; i++) {
      const x = -195 + (i % 4) * 130;
      const y = -85 + Math.floor(i / 4) * 95;
      const item = this.items[i];
      const equipped = this.isEquipped(item);
      const selected = i === this.selected;

      const slot = add(scene.add.rectangle(x, y, 105, 75, selected ? 0x2f4a78 : 0x202c45)
        .setStrokeStyle(2, equipped ? 0xffd66b : selected ? 0x9fc0ff : 0x60769d));

      if (item) {
        const w = this.weaponOf(item);
        const second = w ? (equipped ? "EQUIPADA" : "Daño " + w.damage) : "x" + item.quantity;

        add(scene.add.text(x, y - 4, item.name + "\n" + second, {
          fontSize: "14px",
          color: equipped ? "#ffd66b" : "#ffffff",
          align: "center",
          wordWrap: { width: 98 }
        }).setOrigin(0.5));

        slot.setInteractive({ useHandCursor: true });
        slot.on("pointerdown", () => {
          this.selected = i;
          this.message = "";
          this.draw();
        });
      }
    }

    // barra inferior: objeto seleccionado + botón USAR
    const sel = this.items[this.selected];

    if (sel) {
      const w = this.weaponOf(sel);
      const equipped = this.isEquipped(sel);

      add(scene.add.text(-250, 177, sel.name + (w ? "  ·  Daño " + w.damage : ""), {
        fontSize: "17px",
        color: "#dce5ff"
      }).setOrigin(0, 0.5));

      if (equipped) {
        add(scene.add.text(190, 177, "EQUIPADA", {
          fontSize: "18px",
          color: "#ffd66b",
          backgroundColor: "#263956",
          padding: { x: 14, y: 8 }
        }).setOrigin(0.5));
      } else {
        const use = add(scene.add.text(190, 177, "USAR", {
          fontSize: "20px",
          color: "#ffffff",
          backgroundColor: "#2f6b4a",
          padding: { x: 22, y: 9 }
        }).setOrigin(0.5));

        use.setInteractive({ useHandCursor: true });
        use.on("pointerdown", () => this.useItem(sel));
      }
    } else {
      add(scene.add.text(0, 177, this.message || "Toca un objeto para usarlo", {
        fontSize: "16px",
        color: this.message ? "#9be8c1" : "#8fa0c8"
      }).setOrigin(0.5));
    }

    if (sel && this.message) {
      add(scene.add.text(0, 140, this.message, {
        fontSize: "16px",
        color: "#9be8c1"
      }).setOrigin(0.5));
    }

    const close = add(scene.add.text(225, -195, "✕", {
      fontSize: "28px",
      color: "#ff8295",
      padding: { x: 14, y: 10 }
    }));

    close.setInteractive({ useHandCursor: true });
    close.on("pointerdown", () => this.toggle());
  }
}
