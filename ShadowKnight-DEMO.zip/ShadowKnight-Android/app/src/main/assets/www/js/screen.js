// Pantalla completa: ocultar barras del sistema y llenar toda la pantalla sin bordes negros
let GAME_W = 1280;
const GAME_H = 720;
let SAFE_L = 0;
let SAFE_R = 0;

function computeScreen() {
  const aspect = window.innerWidth / Math.max(1, window.innerHeight);
  GAME_W = Math.round(GAME_H * Math.min(2.4, Math.max(16 / 9, aspect)));
}

function readSafeArea() {
  try {
    const cs = getComputedStyle(document.documentElement);
    const k = GAME_H / Math.max(1, window.innerHeight);
    SAFE_L = Math.round((parseFloat(cs.getPropertyValue("--safe-area-inset-left")) || 0) * k);
    SAFE_R = Math.round((parseFloat(cs.getPropertyValue("--safe-area-inset-right")) || 0) * k);
  } catch (e) {}
}

function hideSystemBars() {
  try {
    const cap = window.Capacitor;
    if (cap && cap.nativePromise) {
      cap.nativePromise("SystemBars", "hide", {}).catch(() => {});
    }
  } catch (e) {}
}

["pointerdown", "touchstart"].forEach(ev =>
  window.addEventListener(ev, hideSystemBars, { passive: true })
);
window.addEventListener("focus", hideSystemBars);
window.addEventListener("resize", () => setTimeout(hideSystemBars, 200));
document.addEventListener("visibilitychange", () => {
  if (!document.hidden) hideSystemBars();
});
[200, 800, 2000].forEach(t => setTimeout(hideSystemBars, t));
