// ======================================================
//  LOBBY: perfil, colores, tienda de personajes y partida guardada
// ======================================================
class LobbyScene extends Phaser.Scene {
  constructor() {
    super("Lobby");
  }

  preload() {
    ["idle", "walk1", "walk2", "jump", "attack"].forEach(n => {
      if (!this.textures.exists("ksrc_" + n)) {
        this.load.image("ksrc_" + n, "img/knight_" + n + ".png");
      }
    });
  }

  create() {
    this.profile = loadProfile();
    this.save = loadSave();
    this.ui = [];
    this.modal = [];
    this.shopUI = [];
    this.shopOpen = false;
    this.shopMsg = "";

    this.drawBackground();
    this.buildMain();
    this.cameras.main.fadeIn(400, 0, 0, 0);
  }

  // ---------- utilidades ----------
  drawBackground() {
    this.add.rectangle(GAME_W / 2, 360, GAME_W, 720, 0x060912).setDepth(-10);
    this.add.circle(GAME_W * 0.28, 330, 300, 0x2a3f7a, 0.10).setDepth(-9);
    this.add.circle(GAME_W * 0.78, 300, 260, 0x5a2a7a, 0.08).setDepth(-9);
    for (let i = 0; i < 18; i++) {
      const dot = this.add.circle(
        Phaser.Math.Between(20, GAME_W - 20),
        Phaser.Math.Between(20, 700),
        Phaser.Math.Between(1, 3), 0xaec2ff, 0.35
      ).setDepth(-8);
      this.tweens.add({
        targets: dot,
        y: dot.y - Phaser.Math.Between(30, 90),
        alpha: 0.05,
        duration: Phaser.Math.Between(2500, 5000),
        yoyo: true,
        repeat: -1
      });
    }
  }

  button(list, x, y, label, color, size, cb, depth = 10) {
    const t = this.add.text(x, y, label, {
      fontSize: size,
      color: "#ffffff",
      backgroundColor: color,
      padding: { x: 26, y: 14 },
      align: "center"
    }).setOrigin(0.5).setDepth(depth).setInteractive({ useHandCursor: true });
    t.on("pointerdown", cb);
    list.push(t);
    return t;
  }

  clear(list) {
    list.forEach(o => o.destroy());
    list.length = 0;
  }

  coins() {
    return this.save ? this.save.coins : 0;
  }

  // ---------- pantalla principal ----------
  buildMain() {
    this.clear(this.ui);
    const ui = this.ui;
    const add = (o, d = 10) => { o.setDepth(d); ui.push(o); return o; };

    const cx = GAME_W / 2;
    const L = Math.round(GAME_W * 0.30);
    const R = Math.round(GAME_W * 0.74);
    const sel = getCharacter(this.profile.selected);

    add(this.add.text(cx, 46, "SHADOW KNIGHT DEMO", {
      fontSize: "40px", color: "#ffd66b", fontStyle: "bold"
    }).setOrigin(0.5));
    add(this.add.text(cx, 86, "Versión de prueba · 5 niveles · 2 mundos", {
      fontSize: "16px", color: "#8fa0c8"
    }).setOrigin(0.5));

    add(this.add.text(GAME_W - 30, 46, "🪙 " + this.coins(), {
      fontSize: "28px", color: "#ffd66b", fontStyle: "bold"
    }).setOrigin(1, 0.5));

    // ----- perfil (izquierda) -----
    add(this.add.rectangle(L, 366, 540, 572, 0x0d1424, 0.88).setStrokeStyle(3, 0x3d5078), 5);
    add(this.add.text(L, 104, "👤 PERFIL", {
      fontSize: "22px", color: "#8fa0c8", fontStyle: "bold"
    }).setOrigin(0.5));

    add(this.add.ellipse(L, 478, 240, 40, 0x1c2742), 6);

    const key = knightPrefix(this, sel.id, this.profile.hueIdx) + "idle";
    const knight = add(this.add.image(L, 484, key).setOrigin(0.5, 1).setScale(1.5), 8);
    this.tweens.add({
      targets: knight, y: 478, duration: 900, yoyo: true, repeat: -1, ease: "Sine.inOut"
    });

    add(this.add.text(L, 520, sel.name, {
      fontSize: "27px", color: "#ffffff", fontStyle: "bold"
    }).setOrigin(0.5));

    add(this.add.text(L, 558, "COLOR  ·  " + PALETTE[this.profile.hueIdx].name, {
      fontSize: "18px", color: "#8fa0c8"
    }).setOrigin(0.5));

    // paleta de colores
    const gap = 58;
    const x0 = L - (PALETTE.length - 1) * gap / 2;
    PALETTE.forEach((p, i) => {
      const x = x0 + i * gap;
      const active = i === this.profile.hueIdx;
      add(this.add.circle(x, 604, 21, hslHex(p.hue, 0.72, 0.55))
        .setStrokeStyle(active ? 5 : 2, active ? 0xffffff : 0x1a2238));
      const zone = add(this.add.zone(x, 604, 54, 54).setInteractive({ useHandCursor: true }), 11);
      zone.on("pointerdown", () => {
        this.profile.hueIdx = i;
        saveProfile(this.profile);
        this.buildMain();
      });
    });

    // ----- partida (derecha) -----
    add(this.add.rectangle(R, 300, 480, 380, 0x0d1424, 0.88).setStrokeStyle(3, 0x3d5078), 5);

    if (this.save) {
      const s = this.save;
      const st = getStage(s.level);
      add(this.add.text(R, 140, "PARTIDA GUARDADA", {
        fontSize: "24px", color: "#8fa0c8", fontStyle: "bold"
      }).setOrigin(0.5));
      add(this.add.text(R, 196, "Nivel " + s.level + " / " + TOTAL_LEVELS, {
        fontSize: "40px", color: "#ffffff", fontStyle: "bold"
      }).setOrigin(0.5));
      add(this.add.text(R, 244, "Mundo " + (s.level <= 3 ? 1 : 2) + ": " + st.world, {
        fontSize: "22px", color: "#c7d5ff"
      }).setOrigin(0.5));
      add(this.add.text(R, 290, "🪙 " + s.coins + " monedas", {
        fontSize: "24px", color: "#ffd66b"
      }).setOrigin(0.5));
      add(this.add.text(R, 328, "Arma: " + (s.weapon || "Espada de hierro"), {
        fontSize: "20px", color: "#dce5ff"
      }).setOrigin(0.5));
      add(this.add.text(R, 362, "Guardada: " + this.formatDate(s.savedAt), {
        fontSize: "16px", color: "#7f8fb5"
      }).setOrigin(0.5));

      this.button(ui, R, 420, "▶  CONTINUAR", "#2f6b4a", "32px", () => {
        startFromSave(this.save);
        this.scene.start("ShadowKnight");
      });
      this.button(ui, R, 490, "🗑  ELIMINAR", "#7a3040", "24px", () => this.confirmDelete());
    } else {
      add(this.add.text(R, 190, "Sin partida guardada", {
        fontSize: "28px", color: "#ffffff", fontStyle: "bold"
      }).setOrigin(0.5));
      add(this.add.text(R, 260, "¡Comienza tu aventura\ny derrota a los 6 jefes!", {
        fontSize: "22px", color: "#c7d5ff", align: "center"
      }).setOrigin(0.5));
      this.button(ui, R, 400, "▶  NUEVA PARTIDA", "#2f6b4a", "30px", () => {
        resetRuntime();
        this.scene.start("ShadowKnight");
      });
    }

    this.button(ui, R, 600, "👥  PERSONAJES", "#2d4a7a", "28px", () => this.openCharacters());

    if (this.shopOpen) this.openCharacters();
  }

  formatDate(ts) {
    if (!ts) return "—";
    const d = new Date(ts);
    const p = n => String(n).padStart(2, "0");
    return p(d.getDate()) + "/" + p(d.getMonth() + 1) + " " + p(d.getHours()) + ":" + p(d.getMinutes());
  }

  // ---------- eliminar partida ----------
  confirmDelete() {
    if (this.modal.length) return;
    const m = this.modal;
    const cx = GAME_W / 2;
    const add = (o, d) => { o.setDepth(d); m.push(o); return o; };

    add(this.add.rectangle(cx, 360, GAME_W, 720, 0x000000, 0.78).setInteractive(), 60);
    add(this.add.rectangle(cx, 360, 640, 300, 0x10182a, 0.98).setStrokeStyle(3, 0x8c9dce), 61);
    add(this.add.text(cx, 290, "¿Eliminar la partida?\nSe perderán tu progreso y tus monedas.", {
      fontSize: "28px", color: "#ffffff", align: "center"
    }).setOrigin(0.5), 62);

    this.button(m, cx - 150, 410, "SÍ, ELIMINAR", "#7a3040", "24px", () => {
      deleteSave();
      this.save = null;
      this.clear(this.modal);
      this.buildMain();
    }, 63);
    this.button(m, cx + 150, 410, "CANCELAR", "#26344f", "24px", () => this.clear(this.modal), 63);
  }

  // ---------- tienda de personajes ----------
  openCharacters() {
    this.clear(this.shopUI);
    this.shopOpen = true;
    const s = this.shopUI;
    const add = (o, d) => { o.setDepth(d); s.push(o); return o; };

    const cx = GAME_W / 2;
    const panelW = Math.min(1180, GAME_W - 60);

    add(this.add.rectangle(cx, 360, GAME_W, 720, 0x000000, 0.82).setInteractive(), 30);
    add(this.add.rectangle(cx, 360, panelW, 660, 0x10182a, 0.99).setStrokeStyle(3, 0x8c9dce), 31);

    add(this.add.text(cx - panelW / 2 + 34, 62, "PERSONAJES", {
      fontSize: "34px", color: "#ffffff", fontStyle: "bold"
    }).setOrigin(0, 0.5), 32);

    add(this.add.text(cx + panelW / 2 - 130, 62, "🪙 " + this.coins(), {
      fontSize: "26px", color: "#ffd66b", fontStyle: "bold"
    }).setOrigin(1, 0.5), 32);

    const close = add(this.add.text(cx + panelW / 2 - 50, 62, "✕", {
      fontSize: "34px", color: "#ff8295", padding: { x: 16, y: 10 }
    }).setOrigin(0.5), 33);
    close.setInteractive({ useHandCursor: true });
    close.on("pointerdown", () => {
      this.shopOpen = false;
      this.shopMsg = "";
      this.clear(this.shopUI);
    });

    const cardW = 340, cardH = 252, gap = 22;
    const gx0 = cx - (3 * cardW + 2 * gap) / 2 + cardW / 2;

    CHARACTERS.forEach((ch, i) => {
      const x = gx0 + (i % 3) * (cardW + gap);
      const y = 232 + Math.floor(i / 3) * (cardH + gap);
      const owned = this.profile.owned.includes(ch.id);
      const equipped = this.profile.selected === ch.id;

      add(this.add.rectangle(x, y, cardW, cardH, 0x15203a)
        .setStrokeStyle(equipped ? 4 : 2, equipped ? 0xffd66b : 0x3d5078), 32);

      const key = knightPrefix(this, ch.id, this.profile.hueIdx) + "idle";
      add(this.add.image(x, y - 52, key).setScale(0.62), 33);

      add(this.add.text(x, y + 28, ch.name, {
        fontSize: "21px", color: "#ffffff", fontStyle: "bold"
      }).setOrigin(0.5), 33);

      if (equipped) {
        add(this.add.text(x, y + 86, "✔ EQUIPADO", {
          fontSize: "20px", color: "#ffd66b", backgroundColor: "#263956",
          padding: { x: 22, y: 10 }
        }).setOrigin(0.5), 33);
      } else if (owned) {
        this.button(s, x, y + 86, "SELECCIONAR", "#2f6b4a", "20px", () => {
          this.profile.selected = ch.id;
          saveProfile(this.profile);
          this.shopMsg = "";
          this.buildMain();
        }, 33).setPadding(22, 10);
      } else {
        this.button(s, x, y + 86, "COMPRAR · 🪙 " + ch.price, "#7a5a1e", "20px", () => {
          this.buyCharacter(ch);
        }, 33).setPadding(22, 10);
      }
    });

    add(this.add.text(cx, 664, this.shopMsg || "Las monedas se ganan en partida", {
      fontSize: "18px", color: this.shopMsg ? "#ffb3bf" : "#8fa0c8"
    }).setOrigin(0.5), 33);
  }

  buyCharacter(ch) {
    if (this.coins() < ch.price) {
      this.shopMsg = "No tienes suficientes monedas";
      this.openCharacters();
      return;
    }

    this.save.coins -= ch.price;
    writeSave(this.save);

    this.profile.owned.push(ch.id);
    this.profile.selected = ch.id;
    saveProfile(this.profile);

    playMoneySound();
    this.shopMsg = "";
    this.buildMain();   // refresca monedas, vista previa y tienda abierta
  }
}
