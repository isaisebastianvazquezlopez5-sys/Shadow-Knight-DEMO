// DEMO: solo 2 escenarios y 5 niveles en total
const STAGES = [
  {
    world: "Bosque olvidado",
    levels: 3,
    boss: "Guardián de raíces",
    color: 0x315b43,
    difficulty: 1
  },
  {
    world: "Minas oscuras",
    levels: 2,
    boss: "Coloso de piedra",
    color: 0x55566b,
    difficulty: 2
  }
];

const TOTAL_LEVELS = 5; // límite del DEMO

function getStage(level) {
  if (level < 1 || level > TOTAL_LEVELS) return null;

  // Niveles 1-3: Bosque, 4-5: Minas
  let worldIndex = 0;
  if (level >= 4) worldIndex = 1;

  const stage = STAGES[worldIndex];

  return {
    level,
    world: stage.world,
    boss: stage.boss,
    difficulty: stage.difficulty,
    color: stage.color,
    isDemo: true
  };
}
