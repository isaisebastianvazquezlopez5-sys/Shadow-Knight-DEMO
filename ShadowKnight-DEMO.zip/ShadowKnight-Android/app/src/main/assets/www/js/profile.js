// ======================================================
//  PERFIL, PARTIDA GUARDADA Y RECOLOREADO DE SPRITES
// ======================================================
const SAVE_KEY = "sk_demo_save_v1";        // progreso de la partida
const PROFILE_KEY = "sk_demo_profile_v1";  // personajes comprados, personaje elegido y color

// Personajes (caballeros): cambian el color de la armadura
const CHARACTERS = [
  { id: "acero",     name: "Caballero de Acero",   price: 0,    metal: null },
  { id: "carmesi",   name: "Caballero Carmesí",    price: 150,  metal: { h: 355, s: 0.55, l: 0.85 } },
  { id: "esmeralda", name: "Caballero Esmeralda",  price: 300,  metal: { h: 140, s: 0.40, l: 0.90 } },
  { id: "hielo",     name: "Caballero de Hielo",   price: 450,  metal: { h: 190, s: 0.60, l: 1.05 } },
  { id: "oro",       name: "Caballero Dorado",     price: 700,  metal: { h: 45,  s: 0.70, l: 1.00 } },
  { id: "sombra",    name: "Caballero Sombra",     price: 1000, metal: { h: 270, s: 0.30, l: 0.50 } }
];

// Paleta de colores (capa, penacho y botas). hue = tono objetivo; el azul original es ~228
const KNIGHT_BASE_HUE = 228;
const PALETTE = [
  { name: "Azul",     hue: 228 },
  { name: "Cian",     hue: 185 },
  { name: "Verde",    hue: 125 },
  { name: "Amarillo", hue: 52 },
  { name: "Naranja",  hue: 24 },
  { name: "Rojo",     hue: 355 },
  { name: "Rosa",     hue: 320 },
  { name: "Violeta",  hue: 275 }
];

// Un color distinto para cada jefe (caballero rojo gigante recoloreado)
const BOSS_LOOKS = [
  { shift: 130 },                                   // Bosque: verde
  { shift: 53 },                                    // Minas: dorado
  { shift: 195 },                                   // Reino sumergido: cian
  { shift: 290 },                                   // Ciudad maldita: morado
  { shift: 27, satMul: 1.1, lightMul: 1.15 },       // Fortaleza infernal: naranja fuego
  { shift: 270, lightMul: 0.6 }                     // Reino de las sombras: violeta oscuro
];

let KNIGHT_PREFIX = "kn_acero_0_";   // prefijo de las texturas del caballero en uso

// ---------------- almacenamiento ----------------
function storageGet(key) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : null;
  } catch (e) {
    return null;
  }
}

function storageSet(key, val) {
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch (e) {}
}

function getCharacter(id) {
  return CHARACTERS.find(c => c.id === id) || CHARACTERS[0];
}

function loadProfile() {
  const p = storageGet(PROFILE_KEY) || {};
  const owned = Array.isArray(p.owned) ? p.owned.filter(id => CHARACTERS.some(c => c.id === id)) : [];
  if (!owned.includes("acero")) owned.unshift("acero");
  const selected = owned.includes(p.selected) ? p.selected : "acero";
  const hueIdx = Number.isInteger(p.hueIdx) && p.hueIdx >= 0 && p.hueIdx < PALETTE.length ? p.hueIdx : 0;
  return { owned, selected, hueIdx };
}

function saveProfile(p) {
  storageSet(PROFILE_KEY, p);
}

function loadSave() {
  const s = storageGet(SAVE_KEY);
  if (!s || typeof s.level !== "number") return null;
  s.level = Math.min(TOTAL_LEVELS || 5, Math.max(1, Math.round(s.level)));
  s.coins = Math.max(0, Math.round(s.coins || 0));
  s.health = Math.min(100, Math.max(1, Math.round(s.health || 100)));
  s.items = Array.isArray(s.items) ? s.items : [];
  s.purchased = Array.isArray(s.purchased) ? s.purchased : [];
  return s;
}

function writeSave(s) {
  s.savedAt = Date.now();
  storageSet(SAVE_KEY, s);
}

function deleteSave() {
  try { localStorage.removeItem(SAVE_KEY); } catch (e) {}
}

// guarda al salir de la app o al cambiar de pestaña
document.addEventListener("visibilitychange", () => {
  if (document.hidden && typeof saveGame === "function") saveGame();
});
window.addEventListener("pagehide", () => {
  if (typeof saveGame === "function") saveGame();
});

// ---------------- sonido de compra ----------------
let _moneyAudio = null;
function playMoneySound() {
  try {
    if (typeof GameAudio !== "undefined" && GameAudio.muted) return;
    if (!_moneyAudio) _moneyAudio = new Audio("audio/money.mp3");
    _moneyAudio.currentTime = 0;
    const p = _moneyAudio.play();
    if (p && p.catch) p.catch(() => {});
  } catch (e) {}
}

// ---------------- recoloreo por píxel (tono / metal) ----------------
function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
  const l = (mx + mn) / 2, d = mx - mn;
  let h = 0, s = 0;
  if (d > 0) {
    s = d / (1 - Math.abs(2 * l - 1) + 1e-9);
    if (mx === r) h = ((g - b) / d) % 6;
    else if (mx === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  return [h, Math.min(1, s), l];
}

function hslToRgb(h, s, l) {
  h = ((h % 360) + 360) % 360;
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const hp = h / 60;
  const x = c * (1 - Math.abs(hp % 2 - 1));
  const m = l - c / 2;
  let r = 0, g = 0, b = 0;
  switch (Math.floor(hp) % 6) {
    case 0: r = c; g = x; break;
    case 1: r = x; g = c; break;
    case 2: g = c; b = x; break;
    case 3: g = x; b = c; break;
    case 4: r = x; b = c; break;
    default: r = c; b = x;
  }
  return [(r + m) * 255, (g + m) * 255, (b + m) * 255];
}

// o: { shift, metal:{h,s,l}, satMul, lightMul, sLo, sHi }
//  - píxeles muy coloreados (capa, penacho, botas...) rotan su tono (shift)
//  - píxeles grises (armadura) toman el color del "metal" del personaje
function recolorTexture(scene, srcKey, dstKey, o) {
  if (scene.textures.exists(dstKey)) return dstKey;

  const src = scene.textures.get(srcKey).getSourceImage();
  const cv = document.createElement("canvas");
  cv.width = src.width;
  cv.height = src.height;
  const ctx = cv.getContext("2d");
  ctx.drawImage(src, 0, 0);

  let img;
  try {
    img = ctx.getImageData(0, 0, cv.width, cv.height);
  } catch (e) {
    scene.textures.addCanvas(dstKey, cv);
    return dstKey;
  }

  const d = img.data;
  const shift = o.shift || 0;
  const satMul = o.satMul || 1;
  const lightMul = o.lightMul || 1;
  const sLo = o.sLo === undefined ? 0.28 : o.sLo;
  const sHi = o.sHi === undefined ? 0.45 : o.sHi;
  const metal = o.metal || null;

  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] === 0) continue;

    const r = d[i], g = d[i + 1], b = d[i + 2];
    const [h, s, l] = rgbToHsl(r, g, b);
    const w = Math.min(1, Math.max(0, (s - sLo) / (sHi - sLo)));

    const acc = hslToRgb(h + shift, Math.min(1, s * satMul), Math.min(1, l * lightMul));
    const base = metal
      ? hslToRgb(metal.h, metal.s, Math.min(1, l * metal.l))
      : [r, g, b];

    d[i]     = Math.round(w * acc[0] + (1 - w) * base[0]);
    d[i + 1] = Math.round(w * acc[1] + (1 - w) * base[1]);
    d[i + 2] = Math.round(w * acc[2] + (1 - w) * base[2]);
  }

  ctx.putImageData(img, 0, 0);
  scene.textures.addCanvas(dstKey, cv);
  return dstKey;
}

// texturas del caballero (personaje + color) -> devuelve el prefijo, ej. "kn_oro_3_"
function knightPrefix(scene, charId, hueIdx) {
  const ch = getCharacter(charId);
  const shift = PALETTE[hueIdx].hue - KNIGHT_BASE_HUE;
  const prefix = "kn_" + ch.id + "_" + hueIdx + "_";
  ["idle", "walk1", "walk2", "jump", "attack"].forEach(n =>
    recolorTexture(scene, "ksrc_" + n, prefix + n, { shift, metal: ch.metal })
  );
  return prefix;
}

// texturas del jefe de cada mundo (caballero rojo recoloreado)
function bossPrefix(scene, w) {
  const look = BOSS_LOOKS[Math.min(w, BOSS_LOOKS.length - 1)];
  const prefix = "boss" + w + "_";
  ["idle", "walk1", "walk2"].forEach(n =>
    recolorTexture(scene, "enemy_" + n, prefix + n, {
      shift: look.shift,
      satMul: look.satMul,
      lightMul: look.lightMul,
      sLo: 0.38,
      sHi: 0.52
    })
  );
  return prefix;
}

function hslHex(h, s, l) {
  const [r, g, b] = hslToRgb(h, s, l);
  return (Math.round(r) << 16) | (Math.round(g) << 8) | Math.round(b);
}
