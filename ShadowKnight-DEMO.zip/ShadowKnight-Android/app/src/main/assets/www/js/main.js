let player;
let platforms;
let enemies = [];
let cursors;
let keys;
let world;

let inventory;
let shop;
let chestSystem;

let health = 100;
let healthBar;
let coinText;
let levelText;

let controls = {
  left: false,
  right: false,
  jump: false
};

let attackReady = true;

const SPAWN_X = 100;
const SPAWN_Y = 500;
const FALL_LIMIT_Y = 820;
let totalCoins = 0;
let pendingSave = null;   // partida guardada que se aplica al crear inventario y tienda

// vuelve todo a una partida nueva
function resetRuntime() {
  currentLevel = 1;
  health = 100;
  inventory = null;
  shop = null;
  totalCoins = 0;
  pendingSave = null;
}

// prepara el juego para continuar una partida guardada
function startFromSave(save) {
  resetRuntime();
  currentLevel = Math.min(TOTAL_LEVELS, Math.max(1, save.level));
  health = Math.min(100, Math.max(1, save.health || 100));
  pendingSave = save;
}

// guarda el progreso actual (nivel, vida, monedas, mochila, armas)
function saveGame() {
  try {
    if (!inventory || !shop) return;
    const prev = loadSave();
    writeSave({
      level: currentLevel,
      health: health <= 0 ? 100 : Math.max(1, Math.round(health)),
      coins: inventory.coins,
      items: inventory.items.map(i => ({ name: i.name, type: i.type, quantity: i.quantity })),
      purchased: shop.purchased.slice(),
      weapon: shop.currentWeapon ? shop.currentWeapon.name : shop.weapons[0].name,
      startedAt: (prev && prev.startedAt) || Date.now()
    });
  } catch (e) {}
}

// ---------------- NIVELES ----------------
let currentLevel = 1;
// TOTAL_LEVELS definido en stages.js (DEMO = 5)
const LEVEL_W = 2400;
const GROUND_Y = 650;
const EXIT_X = LEVEL_W - 70;          // aquí está la puerta invisible

// ---------------- ENEMIGOS ----------------
const ENEMY_AGGRO_RANGE = 420;        // (base) a esta distancia empiezan a venir
const ENEMY_LOSE_EXTRA = 140;         // si te alejas más, te sueltan
const ENEMY_STOP_DIST = 34;           // se detienen cerca de ti (sin temblar)
const ENEMY_ATTACK_RANGE = 52;        // a esta distancia se quedan quietos atacándote
const ENEMY_PATROL_SPEED = 45;
const ENEMY_PATROL_RANGE = 100;

function makeRng(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shade(color, f) {
  const r = Math.min(255, Math.round(((color >> 16) & 255) * f));
  const g = Math.min(255, Math.round(((color >> 8) & 255) * f));
  const b = Math.min(255, Math.round((color & 255) * f));
  return (r << 16) | (g << 8) | b;
}

// Devuelve plataformas, enemigos y cofres de un nivel (1..30)
function buildLevel(level) {
  const stage = getStage(level);

  // cada 5 niveles (5, 10, ... 30) hay pelea contra el jefe del mundo
  if (level % 5 === 0) {
    return {
      platforms: [
        [1200, 650, 2400],
        [500, 500, 200], [1000, 460, 220], [1500, 500, 200], [2000, 460, 220]
      ],
      enemies: [],
      boss: { x: 1750, y: 480 },
      chests: [[500, 445], [2000, 405]]
    };
  }

  if (level === 1) {
    return {
      platforms: [
        [200, 650, 500], [750, 650, 400], [1250, 650, 500], [1850, 650, 700],
        [2300, 650, 200],
        [500, 490, 180], [950, 410, 180], [1400, 500, 200], [1750, 390, 200], [2150, 490, 180]
      ],
      enemies: [600, 1100, 1600, 2050].map((x, i) => ({
        x, y: 500, hp: 2 + i, dir: i % 2 === 0 ? 1 : -1
      })),
      chests: [[350, 580], [1450, 430], [2200, 420]]
    };
  }

  const rng = makeRng(level * 7919 + 17);
  const diff = stage.difficulty;
  const idx = (level - 1) % 5;
  const platforms = [];

  // suelo: tramos con huecos (más grandes en mundos difíciles)
  platforms.push([225, GROUND_Y, 450]);
  let x = 450;
  while (x < LEVEL_W - 420) {
    const start = x + 70 + rng() * (60 + diff * 22);
    const end = Math.min(start + 320 + rng() * 280, LEVEL_W - 250);
    if (end - start < 200) break;
    platforms.push([(start + end) / 2, GROUND_Y, end - start]);
    x = end;
  }
  platforms.push([LEVEL_W - 125, GROUND_Y, 250]);

  // plataformas flotantes
  const floatCount = 5 + (idx >= 2 ? 1 : 0) + (diff > 3 ? 1 : 0);
  const floating = [];
  for (let k = 0; k < floatCount; k++) {
    const fx = 450 + (k + 0.5) * (1800 / floatCount) + (rng() - 0.5) * 160;
    const fy = 440 + rng() * 80;
    const fw = 150 + rng() * 100;
    floating.push([Math.round(fx), Math.round(fy), Math.round(fw)]);
  }
  platforms.push(...floating);

  // enemigos repartidos por las superficies (menos la de inicio)
  const surfaces = platforms.slice(1).filter(p => p[0] > 650).sort((a, b) => a[0] - b[0]);
  const count = Math.min(10, 4 + Math.floor((level - 1) / 4));
  const enemies = [];
  for (let i = 0; i < count; i++) {
    const surf = surfaces[Math.min(surfaces.length - 1, Math.floor((i + 0.5) * surfaces.length / count))];
    const ex = surf[0] + (rng() - 0.5) * surf[2] * 0.5;
    enemies.push({
      x: Math.round(ex),
      y: surf[1] - 15 - 110,
      hp: 2 + (i % 3) + Math.floor((level - 1) / 3),
      dir: i % 2 === 0 ? 1 : -1
    });
  }

  // cofres sobre plataformas flotantes
  const chests = [0.15, 0.5, 0.85].map(f => {
    const fp = floating[Math.min(floating.length - 1, Math.floor(f * floating.length))];
    return [fp[0], fp[1] - 15 - 40];
  });

  return { platforms, enemies, chests };
}

class ShadowKnightScene extends Phaser.Scene {
  constructor() {
    super("ShadowKnight");
  }

  preload() {
    ["idle", "walk1", "walk2", "jump", "attack"].forEach(n => {
      if (!this.textures.exists("ksrc_" + n)) {
        this.load.image("ksrc_" + n, "img/knight_" + n + ".png");
      }
    });
    ["idle", "walk1", "walk2"].forEach(n => {
      if (!this.textures.exists("enemy_" + n)) {
        this.load.image("enemy_" + n, "img/enemy_" + n + ".png");
      }
    });
  }

  create() {
    const scene = this;
    world = scene;

    this.physics.world.setBounds(0, 0, 2400, 720);
    // sin "suelo" invisible abajo: si te caes, caes de verdad
    this.physics.world.setBoundsCollision(true, true, true, false);
    this.respawning = false;
    this.lastGroundTime = 0;
    this.attackAnimUntil = 0;
    this.wasOnGround = false;
    this.lastVelY = 0;

    // estado de este nivel
    this.transitioning = false;
    this.cleared = false;
    this.jumpBufferUntil = 0;
    this.dead = false;
    this.boss = null;
    this.exitHintAt = 0;
    this.hint = null;
    attackReady = true;
    totalCoins = 0;
    controls.left = controls.right = controls.jump = controls.jumpPress = false;
    this.stage = getStage(currentLevel);
    this.level = buildLevel(currentLevel);

    // personaje y color elegidos en el lobby
    const prof = loadProfile();
    KNIGHT_PREFIX = knightPrefix(this, prof.selected, prof.hueIdx);
    this.nextSave = 0;

    this.createTextures();
    this.createBackground();
    this.createPlatforms();
    this.createPlayer();
    this.createEnemies();
    this.createBoss();
    this.createSystems();
    this.input.addPointer(4);
    readSafeArea();
    this.loadSettings();
    this.createControls();
    this.createHUD();

    this.cameras.main.setBounds(0, 0, 2400, 720);
    this.cameras.main.startFollow(player, true, 0.08, 0.08);
    this.cameras.main.setZoom(1);

    cursors = this.input.keyboard.createCursorKeys();
    keys = this.input.keyboard.addKeys("A,D,W,SPACE,J,I,E");

    this.physics.add.collider(player, platforms);
    this.physics.add.collider(enemies, platforms);
    // los enemigos son sólidos: ya no te atraviesan, se quedan atacándote
    this.physics.add.collider(player, enemies);

    // la vida se conserva entre niveles
    healthBar.width = 170 * (health / 100);
    levelText.setText("NIVEL " + currentLevel + "/" + TOTAL_LEVELS);
    this.cameras.main.fadeIn(500, 0, 0, 0);

    saveGame();   // guarda al empezar cada nivel

    if (!this.level.boss && (currentLevel === 1 || currentLevel === 4)) {
      this.showHint("MUNDO " + (currentLevel <= 3 ? 1 : 2) + "\n" + this.stage.world, 2800);
    }

    // Marca DEMO visible siempre
    this.add.text(GAME_W - 20, 20, "DEMO", {
      fontSize: "22px", color: "#ff6b6b", fontStyle: "bold",
      backgroundColor: "#000000aa", padding: {x:10, y:4}
    }).setOrigin(1,0).setScrollFactor(0).setDepth(600);
  }

  createTextures() {
    const g = this.make.graphics({ x: 0, y: 0, add: false });

    g.fillStyle(0x657da8);
    g.fillRoundedRect(0, 0, 150, 30, 8);
    g.generateTexture("platform", 150, 30);
    g.destroy();
  }

  createBackground() {
    const w = currentLevel <= 3 ? 0 : 1;
    const W = LEVEL_W;
    const pal = [
      { top: 0x08140d, bot: 0x1d3f2c },   // bosque
      { top: 0x0a0b12, bot: 0x252838 },   // minas
      { top: 0x031626, bot: 0x0d5273 },   // reino sumergido
      { top: 0x0d0716, bot: 0x40204f },   // ciudad maldita
      { top: 0x180504, bot: 0x66200f },   // fortaleza infernal
      { top: 0x040208, bot: 0x1e1340 }    // reino de las sombras
    ][w];

    const Col = Phaser.Display.Color;
    const c1 = Col.IntegerToColor(pal.top);
    const c2 = Col.IntegerToColor(pal.bot);
    for (let i = 0; i < 12; i++) {
      const c = Col.Interpolate.ColorWithColor(c1, c2, 11, i);
      this.add.rectangle(W / 2, i * 60 + 30, W, 60, Col.GetColor(c.r, c.g, c.b)).setDepth(-10);
    }

    [this.bgForest, this.bgMines, this.bgSea, this.bgCity, this.bgInferno, this.bgShadow][w].call(this, W);

    for (let i = 0; i < 8; i++) {
      this.add.rectangle(i * 350, 680, 320, 80, shade(this.stage.color, 0.22)).setDepth(-1);
    }
  }

  bgLayer(depth, factor) {
    return this.add.graphics().setDepth(depth).setScrollFactor(factor, 1);
  }

  loopTween(obj, props, min, max) {
    this.tweens.add(Object.assign({
      targets: obj,
      duration: min + Math.random() * (max - min),
      yoyo: true,
      repeat: -1,
      ease: "Sine.easeInOut"
    }, props));
  }

  // MUNDO 1: bosque olvidado — árboles, luna, luciérnagas, niebla
  bgForest(W) {
    this.add.circle(900, 110, 80, 0xd9e8c8, 0.08).setScrollFactor(0.05, 1).setDepth(-9);
    this.add.circle(900, 110, 46, 0xd9e8c8, 0.85).setScrollFactor(0.05, 1).setDepth(-9);

    const far = this.bgLayer(-6, 0.3);
    for (let x = -50; x < W; x += 110) {
      const h = 330 + Math.random() * 200;
      far.fillStyle(0x0f2a1c, 1).fillRect(x, 720 - h, 26, h);
      far.fillStyle(0x12331f, 1).fillEllipse(x + 13, 720 - h, 130 + Math.random() * 60, 110 + Math.random() * 50);
    }

    const mid = this.bgLayer(-4, 0.6);
    for (let x = 0; x < W + 100; x += 190) {
      const h = 400 + Math.random() * 160;
      mid.fillStyle(0x1a3b27, 1).fillRect(x, 720 - h, 34, h);
      mid.fillStyle(0x21512f, 1).fillEllipse(x + 17, 720 - h + 10, 170, 120);
      mid.fillStyle(0x1b4527, 1).fillEllipse(x - 22, 720 - h + 60, 110, 80);
      mid.fillStyle(0x1b4527, 1).fillEllipse(x + 56, 720 - h + 70, 110, 80);
    }

    for (let i = 0; i < 28; i++) {
      const f = this.add.circle(Math.random() * W, 200 + Math.random() * 380, 2.5, 0xe7ff7a, 0.9)
        .setDepth(-2).setScrollFactor(0.8, 1);
      this.loopTween(f, {
        x: f.x + (Math.random() - 0.5) * 120,
        y: f.y + (Math.random() - 0.5) * 90,
        alpha: 0.15
      }, 1800, 4000);
    }

    for (let i = 0; i < 4; i++) {
      this.add.rectangle(W / 2, 560 + i * 35, W, 60, 0x9fd1a8, 0.05).setDepth(-2);
    }
  }

  // MUNDO 2: minas oscuras — paredes de roca, estalactitas, vigas, cristales
  bgMines(W) {
    const wall = this.bgLayer(-6, 0.3);
    for (let x = -40; x < W; x += 150) {
      wall.fillStyle(0x1a1c28, 1).fillRect(x, 720 - (200 + Math.random() * 260), 120, 600);
    }

    const ceil = this.bgLayer(-4, 0.7);
    for (let x = 0; x < W + 100; x += 70) {
      const h = 60 + Math.random() * 150;
      ceil.fillStyle(0x2c3042, 1).fillTriangle(x - 35, 0, x + 35, 0, x + (Math.random() - 0.5) * 20, h);
    }

    const beams = this.bgLayer(-3, 0.85);
    for (let x = 200; x < W + 200; x += 520) {
      beams.fillStyle(0x4a3322, 1).fillRect(x, 150, 22, 520);
      beams.fillStyle(0x5b3f29, 1).fillRect(x - 40, 150, 102, 20);
    }

    const tints = [0x6be5ff, 0xc58bff, 0x8affc1];
    for (let i = 0; i < 16; i++) {
      const cx = Math.random() * W;
      const cy = 330 + Math.random() * 280;
      const col = tints[i % 3];
      const glow = this.add.circle(cx, cy, 44, col, 0.12).setDepth(-3).setScrollFactor(0.85, 1);
      this.loopTween(glow, { alpha: 0.28, scale: 1.25 }, 1200, 2600);
      const cr = this.bgLayer(-3, 0.85);
      cr.fillStyle(col, 0.9).fillTriangle(cx - 10, cy + 26, cx + 10, cy + 26, cx, cy - 34);
      cr.fillStyle(0xffffff, 0.35).fillTriangle(cx - 3, cy + 20, cx + 2, cy + 20, cx, cy - 26);
    }

    for (let i = 0; i < 26; i++) {
      const d = this.add.circle(Math.random() * W, Math.random() * 640, 1.6, 0xcfd6ff, 0.35)
        .setDepth(-2).setScrollFactor(0.9, 1);
      this.loopTween(d, { y: d.y + 60, alpha: 0.05 }, 2500, 5000);
    }
  }

  // MUNDO 3: reino sumergido — rayos de luz, burbujas, algas, peces
  bgSea(W) {
    const rays = this.bgLayer(-8, 0.1);
    for (let i = 0; i < 7; i++) {
      rays.fillStyle(0x8fe6ff, 0.05).fillTriangle(i * 380, 0, i * 380 + 120, 0, i * 380 + 300, 720);
    }

    const far = this.bgLayer(-6, 0.3);
    for (let x = -40; x < W; x += 140) {
      far.fillStyle(0x083a56, 1).fillEllipse(x, 720, 190, 180 + Math.random() * 160);
    }

    for (let x = 30; x < W; x += 85) {
      const h = 110 + Math.random() * 150;
      const weed = this.add.rectangle(x, 700, 14, h, 0x1f8f6a, 0.85)
        .setOrigin(0.5, 1).setDepth(-3).setScrollFactor(0.85, 1);
      this.loopTween(weed, { angle: 7 }, 1400, 2600);
      weed.angle = -7;
    }

    for (let i = 0; i < 36; i++) {
      const b = this.add.circle(Math.random() * W, 720, 3 + Math.random() * 6)
        .setStrokeStyle(1.5, 0xbfeeff, 0.6).setDepth(-2).setScrollFactor(0.8, 1);
      this.tweens.add({
        targets: b,
        y: -30,
        x: b.x + (Math.random() - 0.5) * 80,
        duration: 6000 + Math.random() * 7000,
        delay: Math.random() * 6000,
        repeat: -1
      });
    }

    for (let i = 0; i < 7; i++) {
      const y = 140 + Math.random() * 360;
      const col = [0xffb347, 0x7fdcff, 0xff7a9c][i % 3];
      const fish = this.add.container(0, y, [
        this.add.ellipse(0, 0, 28, 13, col, 0.85),
        this.add.ellipse(-17, 0, 12, 10, col, 0.7),
        this.add.circle(8, -2, 1.8, 0x001018)
      ]).setDepth(-5).setScrollFactor(0.6, 1);
      this.tweens.add({
        targets: fish,
        x: { from: -80, to: W + 80 },
        duration: 16000 + Math.random() * 14000,
        delay: Math.random() * 8000,
        repeat: -1
      });
      this.loopTween(fish, { y: y + 25 }, 1500, 3000);
    }
  }

  // MUNDO 4: ciudad maldita — luna, edificios en ruinas, murciélagos, lápidas
  bgCity(W) {
    this.add.circle(1400, 140, 120, 0xf1e3ff, 0.07).setScrollFactor(0.05, 1).setDepth(-9);
    this.add.circle(1400, 140, 70, 0xf1e3ff, 0.9).setScrollFactor(0.05, 1).setDepth(-9);

    const far = this.bgLayer(-6, 0.3);
    for (let x = -40; x < W; x += 95) {
      const bw = 70 + Math.random() * 40;
      const bh = 220 + Math.random() * 260;
      far.fillStyle(0x1c1030, 1).fillRect(x, 720 - bh, bw, bh);
      if (Math.random() < 0.4) {
        far.fillStyle(0x1c1030, 1).fillTriangle(x, 720 - bh, x + bw, 720 - bh, x + bw / 2, 720 - bh - 70);
      }
      for (let k = 0; k < 6; k++) {
        if (Math.random() < 0.35) {
          far.fillStyle(0xffc857, 0.8).fillRect(x + 10 + (k % 3) * 22, 720 - bh + 24 + Math.floor(k / 3) * 46, 10, 16);
        }
      }
    }

    const mid = this.bgLayer(-4, 0.6);
    for (let x = 20; x < W + 100; x += 230) {
      const bw = 110 + Math.random() * 40;
      const bh = 280 + Math.random() * 200;
      mid.fillStyle(0x120a22, 1).fillRect(x, 720 - bh, bw, bh);
      mid.fillStyle(0x120a22, 1).fillTriangle(x - 8, 720 - bh, x + bw + 8, 720 - bh, x + bw / 2, 720 - bh - 110);
      for (let k = 0; k < 6; k++) {
        if (Math.random() < 0.3) {
          mid.fillStyle(0xff9a3c, 0.85).fillRect(x + 16 + (k % 3) * 30, 720 - bh + 40 + Math.floor(k / 3) * 60, 12, 20);
        }
      }
    }

    for (let i = 0; i < 5; i++) {
      const y = 90 + Math.random() * 200;
      const bat = this.add.container(0, y, [
        this.add.ellipse(-9, 0, 16, 5, 0x05020a).setAngle(-25),
        this.add.ellipse(9, 0, 16, 5, 0x05020a).setAngle(25),
        this.add.circle(0, 1, 3.5, 0x05020a)
      ]).setDepth(-3).setScrollFactor(0.7, 1);
      this.tweens.add({
        targets: bat,
        x: { from: -60, to: W + 60 },
        duration: 11000 + Math.random() * 9000,
        delay: Math.random() * 7000,
        repeat: -1
      });
      this.loopTween(bat, { y: y + 40 }, 700, 1400);
    }

    const graves = this.bgLayer(-2, 0.9);
    for (let x = 60; x < W; x += 170 + Math.random() * 120) {
      graves.fillStyle(0x1a1226, 1).fillRect(x, 610, 26, 40).fillEllipse(x + 13, 610, 26, 22);
      if (Math.random() < 0.4) {
        graves.fillStyle(0x1a1226, 1).fillRect(x + 60, 585, 8, 56).fillRect(x + 48, 600, 32, 8);
      }
    }

    for (let i = 0; i < 3; i++) {
      this.add.rectangle(W / 2, 580 + i * 40, W, 60, 0x9b6bd1, 0.05).setDepth(-2);
    }
  }

  // MUNDO 5: fortaleza infernal — lava, torres, antorchas, brasas
  bgInferno(W) {
    const far = this.bgLayer(-6, 0.3);
    for (let x = -40; x < W; x += 130) {
      const bh = 260 + Math.random() * 280;
      far.fillStyle(0x1b0807, 1).fillRect(x, 720 - bh, 80, bh);
      far.fillStyle(0x1b0807, 1).fillTriangle(x - 6, 720 - bh, x + 86, 720 - bh, x + 40, 720 - bh - 120);
      far.fillStyle(0xff7a2a, 0.85).fillRect(x + 32, 720 - bh + 30, 14, 26);
    }

    const mid = this.bgLayer(-4, 0.6);
    mid.fillStyle(0x2a0e0b, 1).fillRect(0, 380, W, 340);
    for (let x = 0; x < W; x += 60) {
      mid.fillStyle(0x2a0e0b, 1).fillRect(x, 350, 36, 34);
    }

    for (let x = 160; x < W; x += 340) {
      this.add.rectangle(x, 470, 8, 38, 0x3a1a12).setDepth(-3).setScrollFactor(0.6, 1);
      const fl = this.add.circle(x, 442, 13, 0xffa63a, 0.95).setDepth(-3).setScrollFactor(0.6, 1);
      this.loopTween(fl, { scale: 1.4, alpha: 0.6 }, 250, 600);
    }

    const lava = this.add.rectangle(W / 2, 705, W, 120, 0xff5a1a, 0.55).setDepth(-3);
    this.loopTween(lava, { alpha: 0.32 }, 900, 1600);

    for (let i = 0; i < 46; i++) {
      const e = this.add.circle(Math.random() * W, 720, 2 + Math.random() * 2.5, 0xffa040, 0.9)
        .setDepth(-2).setScrollFactor(0.85, 1);
      this.tweens.add({
        targets: e,
        y: -20,
        x: e.x + (Math.random() - 0.5) * 140,
        alpha: 0,
        duration: 3500 + Math.random() * 4500,
        delay: Math.random() * 5000,
        repeat: -1
      });
    }

    for (let i = 0; i < 6; i++) {
      const sm = this.add.ellipse(Math.random() * W, 120 + Math.random() * 160, 260, 70, 0x120403, 0.25)
        .setDepth(-7).setScrollFactor(0.2, 1);
      this.loopTween(sm, { x: sm.x + 120 }, 6000, 11000);
    }
  }

  // MUNDO 6: reino de las sombras — vacío, estrellas, ojo gigante, grietas, espinas
  bgShadow(W) {
    for (let i = 0; i < 90; i++) {
      const st = this.add.circle(Math.random() * W, Math.random() * 600, 1 + Math.random() * 1.6, 0xb9a8ff, 0.4 + Math.random() * 0.5)
        .setDepth(-9).setScrollFactor(0.1, 1);
      this.loopTween(st, { alpha: 0.1 }, 900, 2600);
    }

    this.add.ellipse(1200, 200, 320, 120, 0x120a24, 1).setDepth(-8).setScrollFactor(0.1, 1);
    this.add.circle(1200, 200, 38, 0xff3b5c, 0.9).setDepth(-8).setScrollFactor(0.1, 1);
    const pupil = this.add.ellipse(1200, 200, 12, 50, 0x12020a, 1).setDepth(-8).setScrollFactor(0.1, 1);
    this.loopTween(pupil, { scaleX: 2.2 }, 1500, 2500);

    const rift = this.bgLayer(-6, 0.3);
    rift.lineStyle(3, 0x7a5cff, 0.5);
    for (let x = 250; x < W; x += 520) {
      rift.beginPath();
      rift.moveTo(x, 0);
      for (let y = 40; y <= 720; y += 60) {
        rift.lineTo(x + (Math.random() - 0.5) * 70, y);
      }
      rift.strokePath();
    }

    for (let i = 0; i < 14; i++) {
      const sh = this.add.rectangle(Math.random() * W, 120 + Math.random() * 420, 22, 60, 0x2a1a55, 0.8)
        .setDepth(-5).setScrollFactor(0.5, 1).setAngle(Math.random() * 90);
      this.tweens.add({ targets: sh, angle: sh.angle + 360, duration: 12000 + Math.random() * 12000, repeat: -1 });
    }

    for (let i = 0; i < 18; i++) {
      const x = Math.random() * W;
      const y = 200 + Math.random() * 380;
      this.add.circle(x, y, 18, 0x9a7bff, 0.14).setDepth(-3).setScrollFactor(0.85, 1);
      const wisp = this.add.circle(x, y, 5, 0xc7b5ff, 0.7).setDepth(-3).setScrollFactor(0.85, 1);
      this.loopTween(wisp, { y: y - 50, alpha: 0.25 }, 1800, 3600);
    }

    const spikes = this.bgLayer(-3, 0.9);
    for (let x = -20; x < W + 40; x += 46) {
      spikes.fillStyle(0x0a0614, 1).fillTriangle(x, 720, x + 46, 720, x + 23, 720 - (60 + Math.random() * 70));
    }
  }

  createPlatforms() {
    platforms = this.physics.add.staticGroup();

    const fill = shade(this.stage.color, 1.2);
    const line = shade(this.stage.color, 2.4);

    this.level.platforms.forEach(([x, y, width]) => {
      const platform = this.add.rectangle(
        x,
        y,
        width,
        30,
        fill
      ).setStrokeStyle(2, line);

      this.physics.add.existing(platform, true);
      platforms.add(platform);
    });
  }

  createPlayer() {
    player = this.physics.add.sprite(SPAWN_X, SPAWN_Y, KNIGHT_PREFIX + "idle");
    player.setScale(0.42);

    player.setCollideWorldBounds(true);
    player.setBounce(0);
    player.setMaxVelocity(300, 800);
    player.body.setSize(64, 172, false);
    player.body.setOffset(76, 20);
  }

  createEnemies() {
    enemies = [];
    const lv = currentLevel;
    const w = lv <= 3 ? 0 : 1;
    const tints = [0xffffff, 0xc9c9ee, 0x9fdcff, 0xe0a8ff, 0xff9c88, 0xb59cff];

    // cada nivel los enemigos son más duros
    const speed = Math.min(175, 90 + lv * 2.8);        // siempre más lentos que tú (230)
    const damage = Math.round(6 + lv * 0.55);          // 6 → 22 de daño por golpe
    const interval = Math.max(700, 1100 - lv * 13);    // golpean cada vez más rápido
    const aggro = ENEMY_AGGRO_RANGE + lv * 4;          // te detectan desde más lejos

    this.level.enemies.forEach(spec => {
      const enemy = this.physics.add.sprite(
        spec.x,
        spec.y,
        "enemy_idle"
      );

      enemy.setScale(0.4);
      enemy.body.setSize(64, 170, false);
      enemy.body.setOffset(72, 30);

      enemy.setCollideWorldBounds(true);
      enemy.setBounce(0);
      enemy.setImmovable(false);
      enemy.body.pushable = false;
      enemy.body.setMaxVelocity(300, 900);
      enemy.setTint(tints[w]);
      enemy.health = spec.hp;
      enemy.direction = spec.dir;
      enemy.startX = spec.x;
      enemy.chasing = false;
      enemy.attacking = false;
      enemy.nextAttack = 0;
      enemy.chaseSpeed = speed;
      enemy.damage = damage;
      enemy.attackInterval = interval;
      enemy.aggro = aggro;

      enemies.push(enemy);
    });
  }

  // ---------------- JEFES (niveles 5, 10, 15, 20, 25, 30) ----------------
  createBoss() {
    this.boss = null;
    const spec = this.level.boss;
    if (!spec) return;

    const w = currentLevel <= 3 ? 0 : 1;
    const hp = [32, 48, 70, 95, 125, 170][w];

    this.bossSys = new BossSystem(this);
    const b = this.bossSys.create(this.stage.boss, spec.x, spec.y, hp);

    // el jefe es un caballero rojo gigante, con el color de su mundo
    b.body.destroy();
    b.eye.destroy();

    const prefix = bossPrefix(this, w);
    const scale = 1.0 + w * 0.04;

    const spr = this.physics.add.sprite(spec.x, 430, prefix + "idle");
    spr.setScale(scale);
    spr.setDepth(20);
    spr.body.setSize(64, 170, false);
    spr.body.setOffset(72, 30);
    spr.setCollideWorldBounds(true);
    spr.setBounce(0);
    spr.setImmovable(false);   // inmóvil atravesaría el piso
    spr.body.pushable = false;

    b.body = spr;
    b.eye = this.add.rectangle(spec.x, spec.y, 2, 2, 0x000000, 0).setVisible(false);

    this.physics.add.collider(spr, platforms);
    this.physics.add.collider(player, spr);

    // mismo comportamiento que los caballeros rojos, pero con el DOBLE de daño
    b.prefix = prefix;
    b.dir = -1;
    b.attacking = false;
    b.nextAttack = 0;
    b.chaseSpeed = 100 + w * 10;
    b.damage = Math.round(6 + currentLevel * 0.55) * 2;
    b.attackInterval = Math.max(800, 1250 - currentLevel * 12);
    this.boss = b;

    this.showHint("¡JEFE!\n" + this.stage.boss, 3000);
  }

  bossSwing(b) {
    const dir = b.dir;
    const spr = b.body;
    const slash = this.add.rectangle(spr.x + dir * 100, spr.y + 10, 130, 16, 0xff5a6e)
      .setDepth(25).setRotation(dir * -0.3);

    this.tweens.add({
      targets: slash,
      alpha: 0,
      scaleX: 1.5,
      duration: 240,
      onComplete: () => slash.destroy()
    });
  }

  updateBoss(time) {
    const b = this.boss;
    if (!b || !b.alive) return;

    const spr = b.body;
    const body = spr.body;
    const dx = player.x - spr.x;
    const dy = player.y - spr.y;
    const adx = Math.abs(dx);
    const enraged = b.health < b.maxHealth * 0.5;

    if (enraged && !b.roared) {
      b.roared = true;
      GameAudio.bossRoar();
      this.showHint("¡El jefe se enfurece!", 1500);
    }

    const speed = b.chaseSpeed * (enraged ? 1.3 : 1);
    const inReach = adx < 115 && Math.abs(dy) < 150;

    b.dir = dx >= 0 ? 1 : -1;
    let vx = 0;

    if (inReach) {
      // se queda quieto atacándote
      if (!b.attacking) {
        b.attacking = true;
        b.nextAttack = time + 450;
      }

      if (time >= b.nextAttack) {
        b.nextAttack = time + b.attackInterval * (enraged ? 0.8 : 1);
        this.bossSwing(b);
        this.playerHit(player, { active: true, damage: b.damage });
      }
    } else {
      b.attacking = false;
      vx = b.dir * speed;
    }

    // no se tira al vacío
    if (vx !== 0 && body.blocked.down && !this.hasGroundAhead(spr, Math.sign(vx))) {
      vx = 0;
    }

    body.setVelocityX(vx);

    const walkFrame = Math.floor(time / 230) % 2 ? "walk1" : "walk2";
    spr.setTexture(b.prefix + (vx !== 0 ? walkFrame : "idle"));
    spr.setFlipX(b.dir < 0);
  }

  onBossDefeated() {
    const b = this.boss;
    GameAudio.bossDie();
    if (b.body.body) b.body.body.enable = false;
    inventory.addCoins(100 + currentLevel * 5);
    this.cleared = true;
    this.showHint("¡Jefe derrotado! +" + (100 + currentLevel * 5) + " monedas\nAvanza hacia la derecha ▶", 3200);
    this.time.delayedCall(1200, () => {
      if (this.bossSys && this.bossSys.bar) this.bossSys.bar.destroy();
    });
  }

  applySave(save) {
    inventory.coins = save.coins || 0;
    inventory.items = (save.items || []).map(i => ({ name: i.name, type: i.type, quantity: i.quantity }));

    const names = shop.weapons.map(w => w.name);
    shop.purchased = (save.purchased || []).filter(n => names.includes(n));
    if (!shop.purchased.includes(names[0])) shop.purchased.unshift(names[0]);

    // cada arma comprada debe estar en la mochila
    shop.purchased.forEach(n => {
      if (!inventory.items.some(i => i.name === n)) inventory.addItem(n, "weapon", 1);
    });

    shop.currentWeapon = shop.weapons.find(w => w.name === save.weapon) || shop.weapons[0];
  }

  createSystems() {
    if (!inventory || !shop) {
      inventory = new InventorySystem(this);
      shop = new WeaponShop(this, inventory);
      if (pendingSave) {
        this.applySave(pendingSave);
        pendingSave = null;
      }
    } else {
      // conserva monedas, mochila y armas entre niveles
      inventory.scene = this;
      inventory.visible = false;
      inventory.panel = null;
      shop.scene = this;
      shop.panel = null;
    }

    chestSystem = new ChestSystem(this);
    this.level.chests.forEach(([x, y]) => chestSystem.create(x, y));
  }

  // ---------------- AJUSTES (guardados en el teléfono) ----------------
  loadSettings() {
    const defaults = { btnScale: 1.4, hudScale: 1.0, alpha: 0.85, sound: true, pos: {}, hud: [0, 0] };
    try {
      const saved = JSON.parse(localStorage.getItem("sk_settings") || "{}");
      this.settings = Object.assign({}, defaults, saved);
      this.settings.pos = saved.pos || {};
      this.settings.hud = saved.hud || [0, 0];
    } catch (e) {
      this.settings = defaults;
    }
    GameAudio.setMuted(!this.settings.sound);
  }

  saveSettings() {
    try {
      localStorage.setItem("sk_settings", JSON.stringify(this.settings));
    } catch (e) {}
  }

  get uiLocked() {
    return this.settingsOpen || this.editMode;
  }

  defaultButtonPos(id) {
    const s = this.settings.btnScale;
    const w = 72 * s, h = 68 * s, gap = 14;
    const baseY = 705 - h / 2;
    const jumpX = GAME_W - 15 - SAFE_R - w / 2;
    const topY = 15 + h / 2;
    const map = {
      left:     [15 + SAFE_L + w / 2, baseY],
      right:    [15 + SAFE_L + w * 1.5 + gap, baseY],
      jump:     [jumpX, baseY],
      attack:   [jumpX - w - gap, baseY - h * 0.55 - gap * 0.5],
      settings: [jumpX, topY],
      shop:     [jumpX - (w + gap), topY],
      bag:      [jumpX - 2 * (w + gap), topY]
    };
    return map[id];
  }

  applySettings() {
    const st = this.settings;

    this.touchButtons.forEach(b => {
      const p = st.pos[b.id] || this.defaultButtonPos(b.id);
      b.obj.setScale(st.btnScale);
      b.obj.setAlpha(this.editMode ? 1 : st.alpha);
      b.obj.setPosition(
        Phaser.Math.Clamp(p[0], 20, GAME_W - 20),
        Phaser.Math.Clamp(p[1], 20, 700)
      );
    });

    const s = st.hudScale;
    const ox = 25 + SAFE_L + st.hud[0], oy = 20 + st.hud[1];
    this.hudItems.forEach(it => {
      it.obj.setScale(s);
      it.obj.setPosition(ox + (it.x - 25) * s, oy + (it.y - 20) * s);
    });

    if (this.hudZone) {
      this.hudZone.setPosition(ox - 10, oy - 10);
      this.hudZone.setSize(230 * s, 140 * s);
      this.hudZone.input && this.hudZone.input.hitArea.setSize(230 * s, 140 * s);
    }
  }

  createControls() {
    this.touchButtons = [];
    this.editMode = false;
    this.settingsOpen = false;

    const mk = (id, label, down, up) => this.createTouchButton(id, label, down, up);

    mk("left", "◀", () => { controls.left = true; }, () => { controls.left = false; });
    mk("right", "▶", () => { controls.right = true; }, () => { controls.right = false; });
    mk("jump", "▲", () => { controls.jump = true; controls.jumpPress = true; }, () => { controls.jump = false; });
    mk("attack", "⚔", () => { this.attack(); });
    mk("bag", "🎒", () => { this.toggleInventory(); });
    mk("shop", "🛒", () => { this.openShop(); });
    mk("settings", "⚙", () => { this.openSettings(); });

    // arrastrar en modo edición
    this.input.on("pointermove", pointer => {
      if (!this.dragging || pointer.id !== this.dragging.pointerId) return;
      const d = this.dragging;
      const nx = Phaser.Math.Clamp(pointer.x - d.offX, 20, GAME_W - 20);
      const ny = Phaser.Math.Clamp(pointer.y - d.offY, 20, 700);
      if (d.type === "button") {
        d.btn.obj.setPosition(nx, ny);
      } else {
        this.settings.hud = [
          Phaser.Math.Clamp(pointer.x - d.offX, -20, GAME_W - 280),
          Phaser.Math.Clamp(pointer.y - d.offY, -20, 560)
        ];
        this.applySettings();
      }
    });

    const endDrag = pointer => {
      if (!this.dragging || pointer.id !== this.dragging.pointerId) return;
      if (this.dragging.type === "button") {
        const o = this.dragging.btn.obj;
        this.settings.pos[this.dragging.btn.id] = [Math.round(o.x), Math.round(o.y)];
      }
      this.dragging = null;
      this.saveSettings();
    };
    this.input.on("pointerup", endDrag);
    this.input.on("pointerupoutside", endDrag);
  }

  createTouchButton(id, label, down, up) {
    const button = this.add.text(0, 0, label, {
      fontSize: "32px",
      color: "#ffffff",
      backgroundColor: "#26344f",
      padding: { x: 17, y: 12 }
    });

    button.setOrigin(0.5);
    button.setScrollFactor(0);
    button.setDepth(250);
    button.setInteractive();

    const entry = { id, obj: button };
    this.touchButtons.push(entry);

    button.on("pointerdown", pointer => {
      if (this.settingsOpen) return;
      if (this.editMode) {
        this.dragging = {
          type: "button", btn: entry, pointerId: pointer.id,
          offX: pointer.x - button.x, offY: pointer.y - button.y
        };
        return;
      }
      if (down) down();
    });

    button.on("pointerup", () => {
      if (!this.editMode && up) up();
    });

    button.on("pointerout", () => {
      if (!this.editMode && up) up();
    });
  }

  createHUD() {
    this.hudItems = [];
    const reg = (obj, x, y) => {
      obj.setScrollFactor(0);
      this.hudItems.push({ obj, x, y });
      return obj;
    };

    reg(this.add.text(25, 20, "SHADOW KNIGHT", {
      fontSize: "24px", color: "#c7d5ff", fontStyle: "bold"
    }).setDepth(200), 25, 20);

    reg(this.add.rectangle(110, 75, 170, 14, 0x303448)
      .setOrigin(0, 0.5).setDepth(200), 110, 75);

    healthBar = reg(this.add.rectangle(110, 75, 170, 14, 0x64dba0)
      .setOrigin(0, 0.5).setDepth(201), 110, 75);

    coinText = reg(this.add.text(25, 100, "🪙 0", {
      fontSize: "20px", color: "#ffd66b"
    }).setDepth(200), 25, 100);

    levelText = reg(this.add.text(25, 130, "NIVEL 1", {
      fontSize: "17px", color: "#ffffff"
    }).setDepth(200), 25, 130);

    // zona para mover el HUD en modo edición
    this.hudZone = this.add.rectangle(0, 0, 230, 140, 0x8c9cff, 0.18)
      .setOrigin(0, 0).setScrollFactor(0).setDepth(199).setVisible(false);
    this.hudZone.setInteractive();
    this.hudZone.on("pointerdown", pointer => {
      if (!this.editMode) return;
      this.dragging = {
        type: "hud", pointerId: pointer.id,
        offX: pointer.x - this.settings.hud[0], offY: pointer.y - this.settings.hud[1]
      };
    });

    this.applySettings();
  }

  // ---------------- Panel de ajustes ----------------
  openSettings() {
    if (this.settingsOpen) return;
    if (inventory.visible) inventory.toggle();
    if (shop.panel) { shop.panel.destroy(); shop.panel = null; }

    controls.left = controls.right = controls.jump = false;
    this.settingsOpen = true;
    this.buildSettingsPanel();
  }

  closeSettings() {
    this.settingsOpen = false;
    if (this.settingsUI) {
      this.settingsUI.forEach(o => o.destroy());
      this.settingsUI = null;
    }
    this.saveSettings();
  }

  buildSettingsPanel() {
    const ui = (this.settingsUI = []);
    const dx = GAME_W / 2 - 640;
    const add = o => { o.setScrollFactor(0); ui.push(o); return o; };
    const st = this.settings;

    // fondo que bloquea toques al juego
    add(this.add.rectangle(GAME_W / 2, 360, GAME_W, 720, 0x000000, 0.65)
      .setDepth(600).setInteractive());
    add(this.add.rectangle(GAME_W / 2, 360, 1040, 620, 0x10182a, 0.97)
      .setDepth(601).setStrokeStyle(3, 0x8c9cff));
    add(this.add.text(GAME_W / 2, 90, "⚙ AJUSTES", {
      fontSize: "38px", color: "#c7d5ff", fontStyle: "bold"
    }).setOrigin(0.5).setDepth(602));

    const pct = v => Math.round(v * 100) + "%";
    const btn = (x, y, label, cb, color = "#26344f", size = "34px") => {
      const t = add(this.add.text(x + dx, y, label, {
        fontSize: size, color: "#ffffff", backgroundColor: color,
        padding: { x: 22, y: 12 }, align: "center"
      }).setOrigin(0.5).setDepth(603).setInteractive());
      t.on("pointerdown", cb);
      return t;
    };

    const row = (y, name, getText, minus, plus) => {
      add(this.add.text(160 + dx, y, name, { fontSize: "30px", color: "#ffffff" })
        .setOrigin(0, 0.5).setDepth(602));
      const val = add(this.add.text(900 + dx, y, getText(), {
        fontSize: "30px", color: "#ffd66b", fontStyle: "bold"
      }).setOrigin(0.5).setDepth(602));
      btn(770, y, "−", () => { minus(); val.setText(getText()); this.applySettings(); this.saveSettings(); });
      btn(1030, y, "+", () => { plus(); val.setText(getText()); this.applySettings(); this.saveSettings(); });
    };
    const step = (key, d, min, max) => () => {
      st[key] = Phaser.Math.Clamp(Math.round((st[key] + d) * 100) / 100, min, max);
      if (key === "btnScale") st.pos = {};   // re-acomoda para que no se encimen
    };

    row(185, "Tamaño de botones", () => pct(st.btnScale / 1.0), step("btnScale", -0.1, 0.8, 2.2), step("btnScale", 0.1, 0.8, 2.2));
    row(270, "Tamaño del HUD", () => pct(st.hudScale), step("hudScale", -0.1, 0.6, 2.0), step("hudScale", 0.1, 0.6, 2.0));
    row(355, "Transparencia botones", () => pct(st.alpha), step("alpha", -0.1, 0.3, 1.0), step("alpha", 0.1, 0.3, 1.0));

    add(this.add.text(160 + dx, 440, "Sonido", { fontSize: "30px", color: "#ffffff" })
      .setOrigin(0, 0.5).setDepth(602));
    const snd = btn(900, 440, st.sound ? "ACTIVADO" : "SILENCIO", () => {
      st.sound = !st.sound;
      GameAudio.setMuted(!st.sound);
      snd.setText(st.sound ? "ACTIVADO" : "SILENCIO");
      this.saveSettings();
    }, "#26344f", "26px");

    btn(300, 555, "✋ Editar HUD", () => {
      this.closeSettings();
      this.startEditMode();
    }, "#2d4a7a", "22px");

    btn(530, 555, "Restablecer", () => {
      st.btnScale = 1.4; st.hudScale = 1.0; st.alpha = 0.85; st.pos = {}; st.hud = [0, 0];
      this.applySettings();
      this.saveSettings();
      this.closeSettings();
      this.openSettings();
    }, "#5a3340", "22px");

    btn(760, 555, "🏠 Lobby", () => {
      this.closeSettings();
      saveGame();
      resetRuntime();
      this.scene.start("Lobby");
    }, "#3b3f6b", "22px");

    btn(990, 555, "✔ Cerrar", () => this.closeSettings(), "#2f6b4a", "22px");
  }

  startEditMode() {
    this.editMode = true;
    this.hudZone.setVisible(true);
    this.applySettings();

    const ui = (this.editUI = []);
    const banner = this.add.text(GAME_W / 2, 330, "EDITAR HUD\nArrastra los botones y el HUD\nadonde quieras y toca LISTO", {
      fontSize: "30px", color: "#ffffff", backgroundColor: "#10182acc",
      padding: { x: 24, y: 14 }, align: "center"
    }).setOrigin(0.5).setScrollFactor(0).setDepth(260);
    const done = this.add.text(GAME_W / 2, 480, "✔ LISTO", {
      fontSize: "34px", color: "#ffffff", backgroundColor: "#2f6b4a",
      padding: { x: 30, y: 14 }
    }).setOrigin(0.5).setScrollFactor(0).setDepth(260).setInteractive();
    done.on("pointerdown", () => this.endEditMode());
    ui.push(banner, done);
  }

  endEditMode() {
    this.editMode = false;
    this.dragging = null;
    this.hudZone.setVisible(false);
    if (this.editUI) { this.editUI.forEach(o => o.destroy()); this.editUI = null; }
    this.applySettings();
    this.saveSettings();   // guarda la nueva posición de los controles
  }

  update(time, delta) {
    if (!player || !player.active) return;
    if (this.transitioning || this.dead) return;

    if (time > this.nextSave) {
      this.nextSave = time + 4000;
      saveGame();
    }

    this.handleFall();

    if (this.respawning) return;

    if (inventory.visible || shop.panel || this.uiLocked) {
      player.setVelocityX(0);
      controls.jumpPress = false;
      enemies.forEach(e => { if (e.active) e.setVelocityX(0); });
      if (this.boss && this.boss.alive) this.boss.body.body.setVelocityX(0);
      return;
    }

    const left = controls.left || cursors.left.isDown || keys.A.isDown;
    const right = controls.right || cursors.right.isDown || keys.D.isDown;
    const jump = controls.jump || cursors.up.isDown ||
      keys.W.isDown || keys.SPACE.isDown;

    if (left) {
      player.setVelocityX(-230);
      player.setFlipX(true);
    } else if (right) {
      player.setVelocityX(230);
      player.setFlipX(false);
    } else {
      player.setVelocityX(0);
    }

    const grounded = player.body.blocked.down || player.body.touching.down;
    if (grounded && time > (this.jumpCooldownUntil || 0)) this.lastGroundTime = time;

    const jumpPressed = controls.jumpPress ||
      Phaser.Input.Keyboard.JustDown(cursors.up) ||
      Phaser.Input.Keyboard.JustDown(keys.W) ||
      Phaser.Input.Keyboard.JustDown(keys.SPACE);
    controls.jumpPress = false;

    // un solo salto, y hay que volver a tocar para saltar otra vez
    if (jumpPressed) this.jumpBufferUntil = time + 120;

    if (time < this.jumpBufferUntil && time - this.lastGroundTime < 110) {
      this.jumpBufferUntil = 0;
      this.lastGroundTime = -1000;
      this.jumpCooldownUntil = time + 150;   // evita doble salto / vuelo
      player.setVelocityY(-470);
      GameAudio.jump();
    }

    // un toque = salto normal; mantenido = salto alto y bajada suave
    if (!grounded && jump) {
      player.body.setGravityY(player.body.velocity.y < 0 ? -600 : -400);
      if (player.body.velocity.y > 340) player.setVelocityY(340);
    } else {
      player.body.setGravityY(0);
    }

    // sonido de aterrizaje (gota + golpe) tras una caída o salto
    const onGround = player.body.blocked.down;
    if (onGround && !this.wasOnGround && this.lastVelY > 350) {
      GameAudio.land(Math.min(1, this.lastVelY / 700));
    }
    this.wasOnGround = onGround;
    this.lastVelY = player.body.velocity.y;

    this.animatePlayer(time, left || right);

    if (Phaser.Input.Keyboard.JustDown(keys.J)) {
      this.attack();
    }

    if (Phaser.Input.Keyboard.JustDown(keys.I)) {
      this.toggleInventory();
    }

    if (Phaser.Input.Keyboard.JustDown(keys.E)) {
      this.openShop();
    }

    chestSystem.update(delta);

    if (chestSystem.coins > totalCoins) {
      const earned = chestSystem.coins - totalCoins;
      inventory.addCoins(earned);
      totalCoins = chestSystem.coins;
    }

    coinText.setText("🪙 " + inventory.coins);

    this.updateEnemies(time);
    this.updateBoss(time);
    this.checkLevelExit(time);
  }

  // ---------------- ENEMIGOS: patrullan y te persiguen ----------------
  hasGroundAhead(enemy, dir) {
    const px = enemy.body.center.x + dir * (enemy.body.halfWidth + 14);
    const foot = enemy.body.bottom;

    return platforms.getChildren().some(p => {
      const b = p.body;
      return px >= b.left && px <= b.right &&
        b.top >= foot - 14 && b.top <= foot + 50;
    });
  }

  updateEnemies(time) {
    const walkFrame = Math.floor(time / 230) % 2 ? "enemy_walk1" : "enemy_walk2";

    enemies.forEach(enemy => {
      if (!enemy.active) return;

      if (enemy.y > FALL_LIMIT_Y) {
        enemy.setPosition(enemy.startX, 400);
        enemy.setVelocity(0, 0);
        enemy.chasing = false;
        return;
      }

      const dx = player.x - enemy.x;
      const dy = player.y - enemy.y;
      const adx = Math.abs(dx);

      // histéresis: una vez que te ven, te siguen un poco más lejos
      const range = enemy.chasing ? enemy.aggro + ENEMY_LOSE_EXTRA : enemy.aggro;
      const rangeY = enemy.chasing ? 300 : 220;
      enemy.chasing = adx < range && Math.abs(dy) < rangeY;

      const inReach = adx < ENEMY_ATTACK_RANGE && Math.abs(dy) < 95;

      let vx;
      if (inReach) {
        // se quedan quietos atacándote
        enemy.direction = dx >= 0 ? 1 : -1;
        vx = 0;

        if (!enemy.attacking) {
          enemy.attacking = true;
          enemy.nextAttack = time + 450;   // pequeña pausa antes del primer golpe
        }

        if (time >= enemy.nextAttack) {
          enemy.nextAttack = time + enemy.attackInterval;
          this.enemySwing(enemy);
          this.playerHit(player, enemy);
        }
      } else {
        enemy.attacking = false;

        if (enemy.chasing) {
          enemy.direction = dx >= 0 ? 1 : -1;
          vx = adx > ENEMY_STOP_DIST ? enemy.direction * enemy.chaseSpeed : 0;
        } else {
          if (Math.abs(enemy.x - enemy.startX) > ENEMY_PATROL_RANGE) {
            enemy.direction = enemy.x > enemy.startX ? -1 : 1;
          }
          vx = enemy.direction * ENEMY_PATROL_SPEED;
        }
      }

      // no se tiran al vacío
      if (vx !== 0 && enemy.body.blocked.down &&
          !this.hasGroundAhead(enemy, Math.sign(vx))) {
        if (!enemy.chasing) enemy.direction *= -1;
        vx = 0;
      }

      enemy.setVelocityX(vx);
      enemy.setTexture(vx !== 0 ? walkFrame : "enemy_idle");
      enemy.setFlipX(enemy.direction < 0);
    });
  }

  enemySwing(enemy) {
    const dir = enemy.direction;
    const slash = this.add.rectangle(enemy.x + dir * 36, enemy.y - 5, 54, 9, 0xff5a6e)
      .setDepth(12).setRotation(dir * -0.35);

    this.tweens.add({
      targets: slash,
      alpha: 0,
      scaleX: 1.4,
      duration: 180,
      onComplete: () => slash.destroy()
    });
  }

  deathPuff(x, y) {
    for (let i = 0; i < 8; i++) {
      const p = this.add.circle(x, y, 5 + Math.random() * 4, 0x9b6bff, 0.9).setDepth(30);
      const a = (Math.PI * 2 * i) / 8;
      this.tweens.add({
        targets: p,
        x: x + Math.cos(a) * 55,
        y: y + Math.sin(a) * 55 - 15,
        alpha: 0,
        scale: 0.2,
        duration: 380,
        onComplete: () => p.destroy()
      });
    }
  }

  // ---------------- PUERTA INVISIBLE AL FINAL DEL NIVEL ----------------
  checkLevelExit(time) {
    if (this.transitioning) return;

    const bossAlive = !!(this.boss && this.boss.alive);
    const left = enemies.filter(e => e.active).length + (bossAlive ? 1 : 0);

    if (left === 0 && !this.cleared) {
      this.cleared = true;
      this.showHint("¡Zona despejada!\nAvanza hacia la derecha ▶", 2800);
    }

    if (player.x < EXIT_X) return;

    if (left === 0) {
      this.startLevelTransition();
    } else if (time > this.exitHintAt) {
      this.exitHintAt = time + 2500;
      this.showHint(bossAlive ? "Derrota al jefe para avanzar" : "Derrota a todos los enemigos para avanzar\n(quedan " + left + ")", 2000);
    }
  }

  showHint(text, ms = 2200) {
    if (this.hint) {
      this.tweens.killTweensOf(this.hint);
      this.hint.destroy();
    }

    const t = this.add.text(GAME_W / 2, 150, text, {
      fontSize: "26px",
      color: "#ffffff",
      backgroundColor: "#10182acc",
      padding: { x: 18, y: 10 },
      align: "center"
    }).setOrigin(0.5).setScrollFactor(0).setDepth(260);

    this.hint = t;

    this.tweens.add({
      targets: t,
      alpha: 0,
      delay: ms,
      duration: 500,
      onComplete: () => {
        t.destroy();
        if (this.hint === t) this.hint = null;
      }
    });
  }

  startLevelTransition() {
    if (this.transitioning) return;
    this.transitioning = true;

    controls.left = controls.right = controls.jump = controls.jumpPress = false;
    this.physics.pause();
    // al pasar de nivel recuperas vida (con jefe derrotado, toda)
    health = this.boss ? 100 : Math.min(100, health + 40);

    const FADE = 300;     // se oscurece
    const BLACK = 3000;   // pantalla negra durante 3 segundos

    this.cameras.main.fadeOut(FADE, 0, 0, 0);

    this.time.delayedCall(FADE + BLACK, () => {
      if (currentLevel >= TOTAL_LEVELS) {
        this.showVictory();
        return;
      }
      currentLevel++;
      this.scene.restart();
    });
  }

  showVictory() {
    // DEMO terminado
    this.cameras.main.fadeIn(500, 0, 0, 0);

    this.add.rectangle(GAME_W / 2, 360, GAME_W, 720, 0x05070d, 0.94)
      .setScrollFactor(0).setDepth(700);

    this.add.text(GAME_W / 2, 260, "¡FIN DEL DEMO!", {
      fontSize: "48px", color: "#ffd66b", fontStyle: "bold", align: "center"
    }).setOrigin(0.5).setScrollFactor(0).setDepth(701);

    this.add.text(GAME_W / 2, 340, "Has completado los 5 niveles\nde prueba de SHADOW KNIGHT", {
      fontSize: "26px", color: "#c7d5ff", align: "center"
    }).setOrigin(0.5).setScrollFactor(0).setDepth(701);

    this.add.text(GAME_W / 2, 430, "La versión completa tiene 30 niveles\n6 mundos y jefes épicos.", {
      fontSize: "22px", color: "#8fa0c8", align: "center"
    }).setOrigin(0.5).setScrollFactor(0).setDepth(701);

    this.add.text(GAME_W / 2, 540, "Toca para volver al menú", {
      fontSize: "28px", color: "#ffffff", backgroundColor: "#2f6b4a",
      padding: { x: 28, y: 14 }
    }).setOrigin(0.5).setScrollFactor(0).setDepth(701).setInteractive()
      .on("pointerdown", () => {
        currentLevel = 1;
        health = 100;
        inventory = null;
        shop = null;
        this.scene.start("Lobby");
      });
  }

  animatePlayer(time, moving) {
    let frame = KNIGHT_PREFIX + "idle";

    if (time < this.attackAnimUntil) {
      frame = KNIGHT_PREFIX + "attack";
    } else if (!player.body.blocked.down) {
      frame = KNIGHT_PREFIX + "jump";
    } else if (moving) {
      frame = Math.floor(time / 130) % 2 ? KNIGHT_PREFIX + "walk1" : KNIGHT_PREFIX + "walk2";
    }

    if (player.texture.key !== frame) player.setTexture(frame);
  }

  handleFall() {
    if (this.respawning || player.y < FALL_LIMIT_Y) return;

    this.respawning = true;
    GameAudio.fall();

    player.body.setVelocity(0, 0);
    player.body.setAllowGravity(false);

    const cam = this.cameras.main;
    cam.fadeOut(350, 0, 0, 0);

    cam.once("camerafadeoutcomplete", () => {
      // vuelve a aparecer donde empezó
      player.setPosition(SPAWN_X, SPAWN_Y);
      player.body.setVelocity(0, 0);
      player.body.setAllowGravity(true);
      this.wasOnGround = false;
      this.lastVelY = 0;
      cam.fadeIn(350, 0, 0, 0);
      GameAudio.respawn();

      // breve invulnerabilidad parpadeando
      player.invulnerable = true;
      this.tweens.add({
        targets: player,
        alpha: 0.35,
        yoyo: true,
        repeat: 3,
        duration: 120,
        onComplete: () => {
          player.setAlpha(1);
          player.invulnerable = false;
        }
      });

      this.respawning = false;
    });
  }

  attack() {
    if (!attackReady || inventory.visible || shop.panel || this.uiLocked) return;

    attackReady = false;
    GameAudio.attack();
    this.attackAnimUntil = this.time.now + 220;

    const direction = player.flipX ? -1 : 1;

    const sword = this.add.rectangle(
      player.x + direction * 45,
      player.y,
      65,
      10,
      0x9deaff
    );

    sword.setRotation(direction * -0.3);
    sword.setDepth(100);

    this.tweens.add({
      targets: sword,
      alpha: 0,
      duration: 180,
      onComplete: () => sword.destroy()
    });

    // el daño depende del arma equipada en la tienda
    const dmg = (shop.currentWeapon && shop.currentWeapon.damage) || 1;

    enemies.forEach(enemy => {
      if (!enemy.active) return;

      const closeX = Math.abs(enemy.x - player.x) < 90;
      const closeY = Math.abs(enemy.y - player.y) < 65;
      const inFront = direction > 0
        ? enemy.x > player.x
        : enemy.x < player.x;

      if (closeX && closeY && inFront) {
        enemy.health -= dmg;

        this.tweens.add({
          targets: enemy,
          alpha: 0.3,
          yoyo: true,
          duration: 80,
          repeat: 1
        });

        if (enemy.health <= 0) {
          GameAudio.enemyDie();
          this.deathPuff(enemy.x, enemy.y);
          enemy.destroy();
          inventory.addCoins(10 + Math.floor(currentLevel / 2));
        }
      }
    });

    const boss = this.boss;
    if (boss && boss.alive) {
      const bx = boss.body.x;
      const by = boss.body.y;
      const inFrontB = direction > 0 ? bx > player.x - 20 : bx < player.x + 20;

      if (Math.abs(bx - player.x) < 150 && Math.abs(by - player.y) < 120 && inFrontB) {
        this.bossSys.damage(dmg);
        GameAudio.bossHit();
        if (!boss.alive) this.onBossDefeated();
      }
    }

    this.time.delayedCall(350, () => {
      attackReady = true;
    });
  }

  playerHit(playerObject, enemy) {
    if (playerObject.invulnerable || !enemy.active || this.dead) return;

    GameAudio.hit();
    this.cameras.main.shake(120, 0.004);
    health -= enemy.damage || 10;
    health = Math.max(0, health);

    healthBar.width = 170 * (health / 100);

    playerObject.invulnerable = true;
    playerObject.setTint(0xff7777);

    this.time.delayedCall(650, () => {
      if (playerObject.active) {
        playerObject.invulnerable = false;
        playerObject.clearTint();
      }
    });

    if (health <= 0) {
      this.dead = true;
      this.physics.pause();

      this.add.text(
        GAME_W / 2,
        350,
        "HAS CAÍDO\nToca para reiniciar",
        {
          fontSize: "38px",
          color: "#ff8295",
          align: "center",
          backgroundColor: "#10182a",
          padding: { x: 25, y: 20 }
        }
      ).setOrigin(0.5).setScrollFactor(0).setDepth(500)
        .setInteractive()
        .on("pointerdown", () => {
          health = 100;
          totalCoins = 0;
          this.scene.restart();
        });
    }
  }

  toggleInventory() {
    if (shop.panel) {
      shop.panel.destroy();
      shop.panel = null;
    }

    inventory.toggle();
  }

  openShop() {
    if (inventory.visible) {
      inventory.toggle();
    }

    shop.open();
  }
}

function startGame() {
  computeScreen();
  readSafeArea();

  const config = {
    type: Phaser.AUTO,
    parent: "game",
    width: GAME_W,
    height: 720,
    backgroundColor: "#090d1b",
    physics: {
      default: "arcade",
      arcade: {
        gravity: { y: 1000 },
        debug: false
      }
    },
    scale: {
      mode: Phaser.Scale.FIT,
      autoCenter: Phaser.Scale.CENTER_BOTH
    },
    scene: [LobbyScene, ShadowKnightScene]
  };


  new Phaser.Game(config);
}

function whenLandscape(cb) {
  if (window.innerWidth >= window.innerHeight) { cb(); return; }
  let done = false;
  const go = () => { if (done) return; done = true; window.removeEventListener("resize", go); cb(); };
  window.addEventListener("resize", () => { if (window.innerWidth >= window.innerHeight) go(); });
  setTimeout(go, 2000);
}

// Intro: la imagen aparece con desvanecimiento y desaparece (3 s en total)
function runIntro(cb) {
  const el = document.getElementById("intro");
  if (!el) { cb(); return; }
  el.classList.add("play");
  setTimeout(() => { el.remove(); cb(); }, 3000);
}

function bootGame() {
  try {
    if (screen.orientation && screen.orientation.lock) {
      screen.orientation.lock("landscape").catch(() => {});
    }
  } catch (e) {}

  runIntro(() => whenLandscape(startGame));
}

bootGame();
